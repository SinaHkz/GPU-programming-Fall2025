struct CameraInput
{
    bool W = false;
    bool A = false;
    bool S = false;
    bool D = false;
    bool Q = false; // down
    bool E = false; // up
};

class Camera
{
public:
    float position[3] = { 0.0f, 0.0f, 100.0f };
    float forward[3] = { 0.0f, 0.0f, -1.0f };
    float right[3] = { 1.0f, 0.0f, 0.0f };
    float up[3] = { 0.0f, 1.0f, 0.0f };

    float speed = 100.0f;

    // Call every frame
    void update(const CameraInput& input, float dt);

    // Returns column-major 4x4 view matrix (OpenGL style)
    void getViewMatrix(float view[16]);
};