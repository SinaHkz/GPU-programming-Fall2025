#include <GL/glew.h>
#include <cuda_gl_interop.h>
#include <vector>
#include <cmath>
#include <iostream>
#include "Camera.h"

extern "C" void init_nbody(int N, cudaGraphicsResource * resource);
extern GLuint shaderProgram;
void init_shader();

GLuint instanceVBO;
GLuint sphereVAO;
GLuint sphereVBO;
int sphereVertexCount = 0;

Camera cam;
CameraInput input;

extern cudaGraphicsResource* cuda_vbo_resource;

struct RenderBody {
    float x, y, z;
    float mass;
};

void create_sphere_mesh(int stacks = 8, int slices = 8)
{
    std::vector<float> vertices;

    for (int i = 0; i < stacks; ++i)
    {
        float phi1 = (float)i / stacks * 3.1415926f;
        float phi2 = (float)(i + 1) / stacks * 3.1415926f;

        for (int j = 0; j < slices; ++j)
        {
            float theta1 = (float)j / slices * 2.0f * 3.1415926f;
            float theta2 = (float)(j + 1) / slices * 2.0f * 3.1415926f;

            auto push = [&](float phi, float theta)
            {
                float x = sinf(phi) * cosf(theta);
                float y = cosf(phi);
                float z = sinf(phi) * sinf(theta);
                vertices.push_back(x);
                vertices.push_back(y);
                vertices.push_back(z);
            };

            push(phi1, theta1);
            push(phi2, theta1);
            push(phi2, theta2);

            push(phi1, theta1);
            push(phi2, theta2);
            push(phi1, theta2);
        }
    }

    sphereVertexCount = (int)(vertices.size() / 3);

    glGenVertexArrays(1, &sphereVAO);
    glBindVertexArray(sphereVAO);

    glGenBuffers(1, &sphereVBO);
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER,
        vertices.size() * sizeof(float),
        vertices.data(),
        GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
}

void init_pipeline(int N)
{
    init_shader();
    create_sphere_mesh();

    glGenBuffers(1, &instanceVBO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
    glBufferData(GL_ARRAY_BUFFER, N * sizeof(RenderBody), nullptr, GL_DYNAMIC_DRAW);

    cudaGraphicsGLRegisterBuffer(
        &cuda_vbo_resource,
        instanceVBO,
        cudaGraphicsMapFlagsWriteDiscard);

    glBindVertexArray(sphereVAO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);

    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(RenderBody), (void*)0);
    glVertexAttribDivisor(1, 1);

    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(RenderBody), (void*)(3 * sizeof(float)));
    glVertexAttribDivisor(2, 1);

    init_nbody(N, cuda_vbo_resource);
}

void render(int N)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glUseProgram(shaderProgram);

    float projection[16] = {
        0.1f,0,0,0,
        0,0.1f,0,0,
        0,0,-0.001f,0,
        0,0,0,10
    };

    float view[16] = {
        .1,0,0,0,
        0,.1,0,0,
        0,0,.1,0,
        0,0,0,1
    };

    cam.getViewMatrix(view);
    

    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, projection);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, view);

    glBindVertexArray(sphereVAO);

    glDrawArraysInstanced(
        GL_TRIANGLES,
        0,
        sphereVertexCount,
        N
    );
}
