#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <device_launch_parameters.h>
#include <iostream>
#include <random>

constexpr int BLOCK_SIZE = 128;
constexpr float SOFTENING = 1e-9f;
constexpr float SECS_PER_SEC = 1e10;
constexpr float G = 6.67e-11f;
constexpr float COEFFICIENT = G * SECS_PER_SEC;

struct RenderBody {
    float x, y, z;
    float mass;
};

// Unified memory pointers
float* pos_x, * pos_y, * pos_z;
float* vel_x, * vel_y, * vel_z;
float* acc_x, * acc_y, * acc_z;
float* mass;
int* collision_partner;


cudaGraphicsResource* cuda_vbo_resource;

// ------------------------------------------------------------
// KERNELS
// ------------------------------------------------------------

__global__
void compute_acceleration(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    float* acc_x,
    float* acc_y,
    float* acc_z,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    float px = pos_x[i];
    float py = pos_y[i];
    float pz = pos_z[i];

    float ax = 0.0f;
    float ay = 0.0f;
    float az = 0.0f;

    for (int j = 0; j < N; j++)
    {
        float dx = pos_x[j] - px;
        float dy = pos_y[j] - py;
        float dz = pos_z[j] - pz;

        float distSqr = dx * dx + dy * dy + dz * dz + SOFTENING;
        float invDist = rsqrtf(distSqr);
        float invDist3 = invDist * invDist * invDist;

        float s = mass[j] * invDist3;

        ax += dx * s;
        ay += dy * s;
        az += dz * s;
    }

    acc_x[i] = ax * COEFFICIENT;
    acc_y[i] = ay * COEFFICIENT;
    acc_z[i] = az * COEFFICIENT;
}

__global__
void integrate(
    float* pos_x,
    float* pos_y,
    float* pos_z,
    float* vel_x,
    float* vel_y,
    float* vel_z,
    const float* acc_x,
    const float* acc_y,
    const float* acc_z,
    float dt,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    vel_x[i] += dt * acc_x[i];
    vel_y[i] += dt * acc_y[i];
    vel_z[i] += dt * acc_z[i];

    pos_x[i] += dt * vel_x[i];
    pos_y[i] += dt * vel_y[i];
    pos_z[i] += dt * vel_z[i];
}

__global__
void soa_to_aos(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    RenderBody* out,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    out[i] = { pos_x[i], pos_y[i], pos_z[i], mass[i] };
}

__device__ __forceinline__
float radius_from_mass(float m)
{
    return cbrtf(m) * 0.05f;
}

__global__
void detect_collisions(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    int* collision_partner, // -1 = no collision
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    // Dead bodies (already merged)
    if (mass[i] <= 0.0f)
    {
        collision_partner[i] = -1;
        return;
    }

    float px = pos_x[i];
    float py = pos_y[i];
    float pz = pos_z[i];

    float ri = radius_from_mass(mass[i]);

    int partner = -1;
    float closestDist2 = 1e30f;

    for (int j = 0; j < N; j++)
    {
        if (j == i) continue;
        if (mass[j] <= 0.0f) continue;

        float dx = pos_x[j] - px;
        float dy = pos_y[j] - py;
        float dz = pos_z[j] - pz;

        float dist2 = dx * dx + dy * dy + dz * dz;

        float rj = radius_from_mass(mass[j]);
        float collideDist = ri + rj;

        // Sphere-sphere overlap test (same visual size as render)
        if (dist2 < collideDist * collideDist)
        {
            //pick closest overlap to avoid chaotic multi-merges
            if (dist2 < closestDist2)
            {
                closestDist2 = dist2;
                partner = j;
            }
        }
    }

    collision_partner[i] = partner;
}


__global__
void resolve_collisions(
    float* pos_x,
    float* pos_y,
    float* pos_z,
    float* vel_x,
    float* vel_y,
    float* vel_z,
    float* mass,
    int* collision_partner,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    int j = collision_partner[i];
    if (j < 0 || j <= i) return;
    // j <= i prevents double-merging pairs

    float mi = mass[i];
    float mj = mass[j];

    if (mj <= 0.0f) return; // already merged

    float total_mass = mi + mj;

    // Center of mass position
    pos_x[i] = (pos_x[i] * mi + pos_x[j] * mj) / total_mass;
    pos_y[i] = (pos_y[i] * mi + pos_y[j] * mj) / total_mass;
    pos_z[i] = (pos_z[i] * mi + pos_z[j] * mj) / total_mass;

    // Momentum conservation
    vel_x[i] = (vel_x[i] * mi + vel_x[j] * mj) / total_mass;
    vel_y[i] = (vel_y[i] * mi + vel_y[j] * mj) / total_mass;
    vel_z[i] = (vel_z[i] * mi + vel_z[j] * mj) / total_mass;

    mass[i] = total_mass;

    // "Delete" j by zeroing mass.
    mass[j] = 0.0f;
}


// ------------------------------------------------------------
// API
// ------------------------------------------------------------

extern "C"
void init_nbody(int N, cudaGraphicsResource * resource)
{
    cuda_vbo_resource = resource;

    size_t bytes = N * sizeof(float);

    cudaMallocManaged(&pos_x, bytes);
    cudaMallocManaged(&pos_y, bytes);
    cudaMallocManaged(&pos_z, bytes);

    cudaMallocManaged(&vel_x, bytes);
    cudaMallocManaged(&vel_y, bytes);
    cudaMallocManaged(&vel_z, bytes);

    cudaMallocManaged(&acc_x, bytes);
    cudaMallocManaged(&acc_y, bytes);
    cudaMallocManaged(&acc_z, bytes);

    cudaMallocManaged(&mass, bytes);

    cudaMallocManaged(&collision_partner, N * sizeof(int));

    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-500.f, 500.f);

    // Log-uniform: masses from 0.01 to 1000
    std::uniform_real_distribution<float> log_mass_dist(-2.0f, 3.0f);

    for (int i = 0; i < N; i++)
    {
        pos_x[i] = dist(rng);
        pos_y[i] = dist(rng);
        pos_z[i] = dist(rng);

        vel_x[i] = vel_y[i] = vel_z[i] = 0.f;

        mass[i] = powf(10.0f, log_mass_dist(rng));
    }

    cudaDeviceSynchronize();
}


extern "C"
void nbody_step(float dt, int N)
{
    constexpr int TILE_SIZE = 10000; // max particles per kernel launch
    int threads = BLOCK_SIZE;

    int num_tiles = (N + TILE_SIZE - 1) / TILE_SIZE;

    for (int t = 0; t < num_tiles; ++t)
    {
        int tile_start = t * TILE_SIZE;
        int tile_end = min(tile_start + TILE_SIZE, N);
        int tile_N = tile_end - tile_start;

        int blocks = (tile_N + BLOCK_SIZE - 1) / BLOCK_SIZE;

        compute_acceleration << <blocks, threads >> > (
            pos_x + tile_start,
            pos_y + tile_start,
            pos_z + tile_start,
            mass,
            acc_x + tile_start,
            acc_y + tile_start,
            acc_z + tile_start,
            tile_N);

        integrate << <blocks, threads >> > (
            pos_x + tile_start,
            pos_y + tile_start,
            pos_z + tile_start,
            vel_x + tile_start,
            vel_y + tile_start,
            vel_z + tile_start,
            acc_x + tile_start,
            acc_y + tile_start,
            acc_z + tile_start,
            dt,
            tile_N);
    }
    for (int t = 0; t < num_tiles; ++t)
    {
        int tile_start = t * TILE_SIZE;
        int tile_end = min(tile_start + TILE_SIZE, N);
        int tile_N = tile_end - tile_start;

        int blocks = (tile_N + BLOCK_SIZE - 1) / BLOCK_SIZE;
        detect_collisions << <blocks, threads >> > (
            pos_x + tile_start,
            pos_y + tile_start,
            pos_z + tile_start,
            mass,
            collision_partner,
            tile_N);
    }
    for (int t = 0; t < num_tiles; ++t)
    {
        int tile_start = t * TILE_SIZE;
        int tile_end = min(tile_start + TILE_SIZE, N);
        int tile_N = tile_end - tile_start;

        int blocks = (tile_N + BLOCK_SIZE - 1) / BLOCK_SIZE;
        resolve_collisions << <blocks, threads >> > (
            pos_x + tile_start,
            pos_y + tile_start,
            pos_z + tile_start,
            vel_x + tile_start,
            vel_y + tile_start,
            vel_z + tile_start,
            mass,
            collision_partner,
            tile_N);
    }

    cudaDeviceSynchronize();
}

extern "C"
void update_vbo(int N)
{
    RenderBody* dptr;
    size_t size;

    cudaGraphicsMapResources(1, &cuda_vbo_resource);
    cudaGraphicsResourceGetMappedPointer((void**)&dptr, &size, cuda_vbo_resource);

    int threads = BLOCK_SIZE;
    int blocks = (N + BLOCK_SIZE - 1) / BLOCK_SIZE;

    soa_to_aos << <blocks, threads >> > (
        pos_x, pos_y, pos_z,
        mass,
        dptr,
        N);

    cudaGraphicsUnmapResources(1, &cuda_vbo_resource);
}
