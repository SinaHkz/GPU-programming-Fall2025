#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include "Camera.h"

GLFWwindow* window;

void onResize(GLFWwindow* window, int width, int height) {
    if ((width * 1.f) / (height * 1.f)>(800.f/600.f)) {
        int w = height * (800.f / 600.f);
        glViewport((width - w) / 2, 0, w, height);
    }
    else {
        int h = width * (600.f / 800.f);
        glViewport( 0,(height - h) / 2, width, h);
    }
}

bool init_window(int width, int height)
{
    if (!glfwInit())
        return false;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    window = glfwCreateWindow(width, height, "CUDA NBody", nullptr, nullptr);
    if (!window)
        return false;

    glfwMakeContextCurrent(window);
    glfwSetWindowSizeCallback(window,onResize);

    if (glewInit() != GLEW_OK)
        return false;

    glViewport(0, 0, width, height);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glClearColor(0.02f, 0.02f, 0.05f, 1.0f);

    return true;
}

bool window_should_close()
{
    return glfwWindowShouldClose(window);
}

void swap_buffers()
{
    glfwSwapBuffers(window);
    glfwPollEvents();
}

void shutdown_window()
{
    glfwTerminate();
}

void update_input(CameraInput &input) {
    input.W = glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS;
    input.A = glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS;
    input.S = glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS;
    input.D = glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS;
    input.Q = glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS;
    input.E = glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS;
}
