// camera.cpp
#include <cmath>
#include "Camera.h"

void Camera::update(const CameraInput& input, float dt)
    {
        float velocity = speed * dt;

        if (input.Q)
        {
            position[0] += forward[0] * velocity;
            position[1] += forward[1] * velocity;
            position[2] += forward[2] * velocity;
        }
        if (input.E)
        {
            position[0] -= forward[0] * velocity;
            position[1] -= forward[1] * velocity;
            position[2] -= forward[2] * velocity;
        }
        if (input.A)
        {
            position[0] -= right[0] * velocity;
            position[1] -= right[1] * velocity;
            position[2] -= right[2] * velocity;
        }
        if (input.D)
        {
            position[0] += right[0] * velocity;
            position[1] += right[1] * velocity;
            position[2] += right[2] * velocity;
        }
        if (input.S) // down
        {
            position[0] -= up[0] * velocity;
            position[1] -= up[1] * velocity;
            position[2] -= up[2] * velocity;
        }
        if (input.W) // up
        {
            position[0] += up[0] * velocity;
            position[1] += up[1] * velocity;
            position[2] += up[2] * velocity;
        }
    }

void Camera::getViewMatrix(float view[16])
    {
        // Recompute orthonormal basis (safe even if static camera)
        float f[3] = { forward[0], forward[1], forward[2] };

        // Normalize forward
        float fl = std::sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]);
        if (fl > 0.0f)
        {
            f[0] /= fl; f[1] /= fl; f[2] /= fl;
        }

        // right = normalize(cross(forward, worldUp))
        float worldUp[3] = { 0.0f, 1.0f, 0.0f };
        float r[3] = {
            f[1] * worldUp[2] - f[2] * worldUp[1],
            f[2] * worldUp[0] - f[0] * worldUp[2],
            f[0] * worldUp[1] - f[1] * worldUp[0]
        };

        float rl = std::sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]);
        if (rl > 0.0f)
        {
            r[0] /= rl; r[1] /= rl; r[2] /= rl;
        }

        // up = cross(right, forward)
        float u[3] = {
            r[1] * f[2] - r[2] * f[1],
            r[2] * f[0] - r[0] * f[2],
            r[0] * f[1] - r[1] * f[0]
        };

        // Column-major view matrix (lookAt-style)
        view[0] = r[0];
        view[1] = u[0];
        view[2] = -f[0];
        view[3] = 0.0f;

        view[4] = r[1];
        view[5] = u[1];
        view[6] = -f[1];
        view[7] = 0.0f;

        view[8] = r[2];
        view[9] = u[2];
        view[10] = -f[2];
        view[11] = 0.0f;

        view[12] = -(r[0] * position[0] + r[1] * position[1] + r[2] * position[2]);
        view[13] = -(u[0] * position[0] + u[1] * position[1] + u[2] * position[2]);
        view[14] = (f[0] * position[0] + f[1] * position[1] + f[2] * position[2]);
        view[15] = 1.0f;
    }
