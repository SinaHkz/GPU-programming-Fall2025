#include <GL/glew.h>
#include <cuda_gl_interop.h>
#include <vector>
#include <cmath>
#include <iostream>

extern "C" void init_nbody(int N, cudaGraphicsResource* resource);
extern GLuint shaderProgram;
void init_shader();

GLuint instanceVBO = 0;
GLuint sphereVAO   = 0;
GLuint sphereVBO   = 0;
int sphereVertexCount = 0;

struct RenderBody {
    float x, y, z;
    float mass;
};

void create_sphere_mesh(int stacks = 8, int slices = 8)
{
    std::vector<float> vertices;
    vertices.reserve(stacks * slices * 6 * 3);

    for (int i = 0; i < stacks; ++i)
    {
        float phi1 = (float)i / stacks * 3.1415926f;
        float phi2 = (float)(i + 1) / stacks * 3.1415926f;

        for (int j = 0; j < slices; ++j)
        {
            float theta1 = (float)j / slices * 2.0f * 3.1415926f;
            float theta2 = (float)(j + 1) / slices * 2.0f * 3.1415926f;

            auto push = [&](float phi, float theta)
            {
                float x = sinf(phi) * cosf(theta);
                float y = cosf(phi);
                float z = sinf(phi) * sinf(theta);
                vertices.push_back(x);
                vertices.push_back(y);
                vertices.push_back(z);
            };

            // 2 triangles per quad
            push(phi1, theta1);
            push(phi2, theta1);
            push(phi2, theta2);

            push(phi1, theta1);
            push(phi2, theta2);
            push(phi1, theta2);
        }
    }

    sphereVertexCount = (int)(vertices.size() / 3);

    glGenVertexArrays(1, &sphereVAO);
    glBindVertexArray(sphereVAO);

    glGenBuffers(1, &sphereVBO);
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER,
                 vertices.size() * sizeof(float),
                 vertices.data(),
                 GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    glBindVertexArray(0);
}

void init_pipeline(int N)
{
    init_shader();
    create_sphere_mesh();

    // Instance buffer: N bodies, each is (x,y,z,mass)
    glGenBuffers(1, &instanceVBO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
    glBufferData(GL_ARRAY_BUFFER, (size_t)N * sizeof(RenderBody), nullptr, GL_DYNAMIC_DRAW);

    // Register this VBO with CUDA (LOCAL resource handle)
    cudaGraphicsResource* resource = nullptr;
    cudaError_t err = cudaGraphicsGLRegisterBuffer(
        &resource,
        instanceVBO,
        cudaGraphicsMapFlagsWriteDiscard);

    if (err != cudaSuccess) {
        std::cerr << "cudaGraphicsGLRegisterBuffer failed: "
                  << cudaGetErrorString(err) << "\n";
        return;
    }

    // Bind sphere mesh VAO and attach instance attributes
    glBindVertexArray(sphereVAO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);

    // location 1: vec3 position (x,y,z) from instance buffer
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(RenderBody), (void*)0);
    glVertexAttribDivisor(1, 1);

    // location 2: float mass from instance buffer (offset 3 floats)
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(RenderBody), (void*)(3 * sizeof(float)));
    glVertexAttribDivisor(2, 1);

    glBindVertexArray(0);

    // Pass CUDA resource to simulation
    init_nbody(N, resource);
}

void render(int N)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glUseProgram(shaderProgram);

    float projection[16] = {
        0.1f,0,0,0,
        0,0.1f,0,0,
        0,0,-0.01f,0,
        0,0,0,1
    };

    float view[16] = {
        .5f,0,0,0,
        0,.5f,0,0,
        0,0,.5f,0,
        0,0,0,1
    };

    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, projection);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"),       1, GL_FALSE, view);

    glBindVertexArray(sphereVAO);

    glDrawArraysInstanced(GL_TRIANGLES, 0, sphereVertexCount, N);

    glBindVertexArray(0);
    glUseProgram(0);
}
