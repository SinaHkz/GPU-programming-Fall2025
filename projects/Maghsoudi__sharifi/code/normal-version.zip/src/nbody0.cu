
#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <device_launch_parameters.h>
#include <iostream>
#include <random>
#include <algorithm>


constexpr int BLOCK_SIZE = 128;
constexpr float SOFTENING = 1e-9f;
constexpr float SECS_PER_SEC = 1e10;
constexpr float G = 6.67e-11f;
constexpr float COEFFICIENT = G * SECS_PER_SEC;

struct RenderBody {
    float x, y, z;
    float mass;
};

float* pos_x, * pos_y, * pos_z;
float* vel_x, * vel_y, * vel_z;
float* acc_x, * acc_y, * acc_z;
float* mass;

cudaGraphicsResource* cuda_vbo_resource;


__global__
void compute_acceleration(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    float* acc_x,
    float* acc_y,
    float* acc_z,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    float px = pos_x[i];
    float py = pos_y[i];
    float pz = pos_z[i];

    float ax = 0.0f;
    float ay = 0.0f;
    float az = 0.0f;

    for (int j = 0; j < N; j++)
    {
        float dx = pos_x[j] - px;
        float dy = pos_y[j] - py;
        float dz = pos_z[j] - pz;

        float distSqr = dx * dx + dy * dy + dz * dz + SOFTENING;
        float invDist = rsqrtf(distSqr);
        float invDist3 = invDist * invDist * invDist;

        float s = mass[j] * invDist3;

        ax += dx * s;
        ay += dy * s;
        az += dz * s;
    }

    acc_x[i] = ax * COEFFICIENT;
    acc_y[i] = ay * COEFFICIENT;
    acc_z[i] = az * COEFFICIENT;
}










__global__
void integrate(
    float* pos_x,
    float* pos_y,
    float* pos_z,
    float* vel_x,
    float* vel_y,
    float* vel_z,
    const float* acc_x,
    const float* acc_y,
    const float* acc_z,
    float dt,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    vel_x[i] += dt * acc_x[i];
    vel_y[i] += dt * acc_y[i];
    vel_z[i] += dt * acc_z[i];

    pos_x[i] += dt * vel_x[i];
    pos_y[i] += dt * vel_y[i];
    pos_z[i] += dt * vel_z[i];
}








__global__
void soa_to_aos(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    RenderBody* out,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    out[i] = { pos_x[i], pos_y[i], pos_z[i], mass[i] };
}

// ------------------------------------------------------------
// API
// ------------------------------------------------------------






extern "C"
void init_nbody(int N, cudaGraphicsResource * resource)
{
    cuda_vbo_resource = resource;

    size_t bytes = N * sizeof(float);

    cudaMallocManaged(&pos_x, bytes);
    cudaMallocManaged(&pos_y, bytes);
    cudaMallocManaged(&pos_z, bytes);

    cudaMallocManaged(&vel_x, bytes);
    cudaMallocManaged(&vel_y, bytes);
    cudaMallocManaged(&vel_z, bytes);

    cudaMallocManaged(&acc_x, bytes);
    cudaMallocManaged(&acc_y, bytes);
    cudaMallocManaged(&acc_z, bytes);

    cudaMallocManaged(&mass, bytes);

    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-10.f, 10.f);
    std::uniform_real_distribution<float> mass_dist(0.5f, 5.f);

    for (int i = 0; i < N; i++)
    {
        pos_x[i] = dist(rng);
        pos_y[i] = dist(rng);
        pos_z[i] = dist(rng);

        vel_x[i] = vel_y[i] = vel_z[i] = 0.f;
        mass[i] = mass_dist(rng);
    }

    cudaDeviceSynchronize();
}

extern "C"
void nbody_step(float dt, int N)
{
    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    compute_acceleration<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        mass,
        acc_x, acc_y, acc_z,
        N);

    integrate<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        vel_x, vel_y, vel_z,
        acc_x, acc_y, acc_z,
        dt,
        N);

    cudaDeviceSynchronize();
}


extern "C"
void update_vbo(int N)
{
    RenderBody* dptr;
    size_t size;

    cudaGraphicsMapResources(1, &cuda_vbo_resource);
    cudaGraphicsResourceGetMappedPointer((void**)&dptr, &size, cuda_vbo_resource);

    int threads = BLOCK_SIZE;
    int blocks = (N + BLOCK_SIZE - 1) / BLOCK_SIZE;

    soa_to_aos << <blocks, threads >> > (
        pos_x, pos_y, pos_z,
        mass,
        dptr,
        N);

    cudaGraphicsUnmapResources(1, &cuda_vbo_resource);
}
