#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

GLFWwindow* window;

bool init_window(int width, int height)
{
    if (!glfwInit())
        return false;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    window = glfwCreateWindow(width, height, "CUDA NBody", nullptr, nullptr);
    if (!window)
        return false;

    glfwMakeContextCurrent(window);

    if (glewInit() != GLEW_OK)
        return false;

    glViewport(0, 0, width, height);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glClearColor(0.02f, 0.02f, 0.05f, 1.0f);

    return true;
}

bool window_should_close()
{
    return glfwWindowShouldClose(window);
}

void swap_buffers()
{
    glfwSwapBuffers(window);
    glfwPollEvents();
}

void shutdown_window()
{
    glfwTerminate();
}
