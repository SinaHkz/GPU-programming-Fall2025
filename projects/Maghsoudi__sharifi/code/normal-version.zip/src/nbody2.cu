#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <device_launch_parameters.h>

#include <iostream>
#include <random>
#include <algorithm>

constexpr int   BLOCK_SIZE   = 512;
constexpr float SOFTENING    = 1e-9f;
constexpr float SECS_PER_SEC = 1e10f;
constexpr float G            = 6.67e-11f;
constexpr float COEFFICIENT  = G * SECS_PER_SEC;

struct RenderBody {
    float x, y, z;
    float mass;
};

float *pos_x, *pos_y, *pos_z;
float *vel_x, *vel_y, *vel_z;
float *acc_x, *acc_y, *acc_z;
float *mass;

cudaGraphicsResource* cuda_vbo_resource = nullptr;

__global__
void compute_acceleration(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    float* acc_x,
    float* acc_y,
    float* acc_z,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    float px = pos_x[i];
    float py = pos_y[i];
    float pz = pos_z[i];

    float ax = 0.0f, ay = 0.0f, az = 0.0f;

    __shared__ float4 shPosMass[BLOCK_SIZE];

    for (int tile = 0; tile < N; tile += BLOCK_SIZE)
    {
        int j = tile + threadIdx.x;

        if (j < N) {
            shPosMass[threadIdx.x] = make_float4(pos_x[j], pos_y[j], pos_z[j], mass[j]);
        } else {
            shPosMass[threadIdx.x] = make_float4(0.f, 0.f, 0.f, 0.f);
        }

        __syncthreads();

        int tileCount = min(BLOCK_SIZE, N - tile);

        int k = 0;
        for (; k + 15 < tileCount; k += 16)
        {
            float4 bj0 = shPosMass[k + 0];
            float dx0 = bj0.x - px, dy0 = bj0.y - py, dz0 = bj0.z - pz;
            float distSqr0 = dx0*dx0 + dy0*dy0 + dz0*dz0 + SOFTENING;
            float invDist0 = rsqrtf(distSqr0);
            float s0 = bj0.w * (invDist0 * invDist0 * invDist0);
            ax += dx0*s0; ay += dy0*s0; az += dz0*s0;

            float4 bj1 = shPosMass[k + 1];
            float dx1 = bj1.x - px, dy1 = bj1.y - py, dz1 = bj1.z - pz;
            float distSqr1 = dx1*dx1 + dy1*dy1 + dz1*dz1 + SOFTENING;
            float invDist1 = rsqrtf(distSqr1);
            float s1 = bj1.w * (invDist1 * invDist1 * invDist1);
            ax += dx1*s1; ay += dy1*s1; az += dz1*s1;

            float4 bj2 = shPosMass[k + 2];
            float dx2 = bj2.x - px, dy2 = bj2.y - py, dz2 = bj2.z - pz;
            float distSqr2 = dx2*dx2 + dy2*dy2 + dz2*dz2 + SOFTENING;
            float invDist2 = rsqrtf(distSqr2);
            float s2 = bj2.w * (invDist2 * invDist2 * invDist2);
            ax += dx2*s2; ay += dy2*s2; az += dz2*s2;

            float4 bj3 = shPosMass[k + 3];
            float dx3 = bj3.x - px, dy3 = bj3.y - py, dz3 = bj3.z - pz;
            float distSqr3 = dx3*dx3 + dy3*dy3 + dz3*dz3 + SOFTENING;
            float invDist3 = rsqrtf(distSqr3);
            float s3 = bj3.w * (invDist3 * invDist3 * invDist3);
            ax += dx3*s3; ay += dy3*s3; az += dz3*s3;

            float4 bj4 = shPosMass[k + 4];
            float dx4 = bj4.x - px, dy4 = bj4.y - py, dz4 = bj4.z - pz;
            float distSqr4 = dx4*dx4 + dy4*dy4 + dz4*dz4 + SOFTENING;
            float invDist4 = rsqrtf(distSqr4);
            float s4 = bj4.w * (invDist4 * invDist4 * invDist4);
            ax += dx4*s4; ay += dy4*s4; az += dz4*s4;

            float4 bj5 = shPosMass[k + 5];
            float dx5 = bj5.x - px, dy5 = bj5.y - py, dz5 = bj5.z - pz;
            float distSqr5 = dx5*dx5 + dy5*dy5 + dz5*dz5 + SOFTENING;
            float invDist5 = rsqrtf(distSqr5);
            float s5 = bj5.w * (invDist5 * invDist5 * invDist5);
            ax += dx5*s5; ay += dy5*s5; az += dz5*s5;

            float4 bj6 = shPosMass[k + 6];
            float dx6 = bj6.x - px, dy6 = bj6.y - py, dz6 = bj6.z - pz;
            float distSqr6 = dx6*dx6 + dy6*dy6 + dz6*dz6 + SOFTENING;
            float invDist6 = rsqrtf(distSqr6);
            float s6 = bj6.w * (invDist6 * invDist6 * invDist6);
            ax += dx6*s6; ay += dy6*s6; az += dz6*s6;

            float4 bj7 = shPosMass[k + 7];
            float dx7 = bj7.x - px, dy7 = bj7.y - py, dz7 = bj7.z - pz;
            float distSqr7 = dx7*dx7 + dy7*dy7 + dz7*dz7 + SOFTENING;
            float invDist7 = rsqrtf(distSqr7);
            float s7 = bj7.w * (invDist7 * invDist7 * invDist7);
            ax += dx7*s7; ay += dy7*s7; az += dz7*s7;

            float4 bj8 = shPosMass[k + 8];
            float dx8 = bj8.x - px, dy8 = bj8.y - py, dz8 = bj8.z - pz;
            float distSqr8 = dx8*dx8 + dy8*dy8 + dz8*dz8 + SOFTENING;
            float invDist8 = rsqrtf(distSqr8);
            float s8 = bj8.w * (invDist8 * invDist8 * invDist8);
            ax += dx8*s8; ay += dy8*s8; az += dz8*s8;

            float4 bj9 = shPosMass[k + 9];
            float dx9 = bj9.x - px, dy9 = bj9.y - py, dz9 = bj9.z - pz;
            float distSqr9 = dx9*dx9 + dy9*dy9 + dz9*dz9 + SOFTENING;
            float invDist9 = rsqrtf(distSqr9);
            float s9 = bj9.w * (invDist9 * invDist9 * invDist9);
            ax += dx9*s9; ay += dy9*s9; az += dz9*s9;

            float4 bj10 = shPosMass[k + 10];
            float dx10 = bj10.x - px, dy10 = bj10.y - py, dz10 = bj10.z - pz;
            float distSqr10 = dx10*dx10 + dy10*dy10 + dz10*dz10 + SOFTENING;
            float invDist10 = rsqrtf(distSqr10);
            float s10 = bj10.w * (invDist10 * invDist10 * invDist10);
            ax += dx10*s10; ay += dy10*s10; az += dz10*s10;

            float4 bj11 = shPosMass[k + 11];
            float dx11 = bj11.x - px, dy11 = bj11.y - py, dz11 = bj11.z - pz;
            float distSqr11 = dx11*dx11 + dy11*dy11 + dz11*dz11 + SOFTENING;
            float invDist11 = rsqrtf(distSqr11);
            float s11 = bj11.w * (invDist11 * invDist11 * invDist11);
            ax += dx11*s11; ay += dy11*s11; az += dz11*s11;

            float4 bj12 = shPosMass[k + 12];
            float dx12 = bj12.x - px, dy12 = bj12.y - py, dz12 = bj12.z - pz;
            float distSqr12 = dx12*dx12 + dy12*dy12 + dz12*dz12 + SOFTENING;
            float invDist12 = rsqrtf(distSqr12);
            float s12 = bj12.w * (invDist12 * invDist12 * invDist12);
            ax += dx12*s12; ay += dy12*s12; az += dz12*s12;

            float4 bj13 = shPosMass[k + 13];
            float dx13 = bj13.x - px, dy13 = bj13.y - py, dz13 = bj13.z - pz;
            float distSqr13 = dx13*dx13 + dy13*dy13 + dz13*dz13 + SOFTENING;
            float invDist13 = rsqrtf(distSqr13);
            float s13 = bj13.w * (invDist13 * invDist13 * invDist13);
            ax += dx13*s13; ay += dy13*s13; az += dz13*s13;

            float4 bj14 = shPosMass[k + 14];
            float dx14 = bj14.x - px, dy14 = bj14.y - py, dz14 = bj14.z - pz;
            float distSqr14 = dx14*dx14 + dy14*dy14 + dz14*dz14 + SOFTENING;
            float invDist14 = rsqrtf(distSqr14);
            float s14 = bj14.w * (invDist14 * invDist14 * invDist14);
            ax += dx14*s14; ay += dy14*s14; az += dz14*s14;

            float4 bj15 = shPosMass[k + 15];
            float dx15 = bj15.x - px, dy15 = bj15.y - py, dz15 = bj15.z - pz;
            float distSqr15 = dx15*dx15 + dy15*dy15 + dz15*dz15 + SOFTENING;
            float invDist15 = rsqrtf(distSqr15);
            float s15 = bj15.w * (invDist15 * invDist15 * invDist15);
            ax += dx15*s15; ay += dy15*s15; az += dz15*s15;
        }

        for (; k < tileCount; k++)
        {
            float4 bj = shPosMass[k];
            float dx = bj.x - px;
            float dy = bj.y - py;
            float dz = bj.z - pz;

            float distSqr = dx*dx + dy*dy + dz*dz + SOFTENING;
            float invDist  = rsqrtf(distSqr);
            float invDist3 = invDist * invDist * invDist;

            float s = bj.w * invDist3;

            ax += dx * s;
            ay += dy * s;
            az += dz * s;
        }

        __syncthreads();
    }

    acc_x[i] = ax * COEFFICIENT;
    acc_y[i] = ay * COEFFICIENT;
    acc_z[i] = az * COEFFICIENT;
}




__global__
void integrate(
    float* __restrict__ pos_x,
    float* __restrict__ pos_y,
    float* __restrict__ pos_z,
    float* __restrict__ vel_x,
    float* __restrict__ vel_y,
    float* __restrict__ vel_z,
    const float* __restrict__ acc_x,
    const float* __restrict__ acc_y,
    const float* __restrict__ acc_z,
    float dt,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    vel_x[i] += dt * acc_x[i];
    vel_y[i] += dt * acc_y[i];
    vel_z[i] += dt * acc_z[i];

    pos_x[i] += dt * vel_x[i];
    pos_y[i] += dt * vel_y[i];
    pos_z[i] += dt * vel_z[i];
}

__global__
void soa_to_aos(
    const float* __restrict__ pos_x,
    const float* __restrict__ pos_y,
    const float* __restrict__ pos_z,
    const float* __restrict__ mass,
    RenderBody* __restrict__ out,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    out[i] = { pos_x[i], pos_y[i], pos_z[i], mass[i] };
}


extern "C"
void init_nbody(int N, cudaGraphicsResource* resource)
{
    cuda_vbo_resource = resource;

    size_t bytes = static_cast<size_t>(N) * sizeof(float);

    cudaMallocManaged(&pos_x, bytes);
    cudaMallocManaged(&pos_y, bytes);
    cudaMallocManaged(&pos_z, bytes);

    cudaMallocManaged(&vel_x, bytes);
    cudaMallocManaged(&vel_y, bytes);
    cudaMallocManaged(&vel_z, bytes);

    cudaMallocManaged(&acc_x, bytes);
    cudaMallocManaged(&acc_y, bytes);
    cudaMallocManaged(&acc_z, bytes);

    cudaMallocManaged(&mass, bytes);

    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-10.f, 10.f);
    std::uniform_real_distribution<float> mass_dist(0.5f, 5.f);

    for (int i = 0; i < N; i++)
    {
        pos_x[i] = dist(rng);
        pos_y[i] = dist(rng);
        pos_z[i] = dist(rng);

        vel_x[i] = vel_y[i] = vel_z[i] = 0.f;
        mass[i]  = mass_dist(rng);
    }

    cudaDeviceSynchronize();
}

extern "C"
void nbody_step(float dt, int N)
{
    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    compute_acceleration<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        mass,
        acc_x, acc_y, acc_z,
        N);

    integrate<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        vel_x, vel_y, vel_z,
        acc_x, acc_y, acc_z,
        dt,
        N);

    cudaDeviceSynchronize();
}

extern "C"
void update_vbo(int N)
{
    RenderBody* dptr = nullptr;
    size_t size = 0;

    cudaGraphicsMapResources(1, &cuda_vbo_resource);
    cudaGraphicsResourceGetMappedPointer((void**)&dptr, &size, cuda_vbo_resource);

    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    soa_to_aos<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        mass,
        dptr,
        N);

    cudaGraphicsUnmapResources(1, &cuda_vbo_resource);
}
