#include <GL/glew.h>
#include <iostream>

GLuint shaderProgram;

static GLuint compile_shader(GLenum type, const char* src)
{
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);

    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);

    if (!success)
    {
        char info[512];
        glGetShaderInfoLog(shader, 512, nullptr, info);
        std::cout << "Shader compile error:\n" << info << std::endl;
    }

    return shader;
}

void init_shader()
{
    const char* vertexSrc = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec3 instancePos;
    layout (location = 2) in float mass;

    uniform mat4 projection;
    uniform mat4 view;

    out vec3 vColor;

    float hash(float n)
    {
        return fract(sin(n) * 43758.5453);
    }

    void main()
    {
        float scale = 0.02 + pow(mass, 1.0 / 3.0) * 0.05;
        vec3 pos = aPos * scale + instancePos;

        gl_Position = projection * view * vec4(pos, 1.0);

        float id = float(gl_InstanceID);
        vColor = vec3(
            hash(id),
            hash(id * 1.37),
            hash(id * 2.17)
        );
    }
    )";

    const char* fragmentSrc = R"(
    #version 330 core
    in vec3 vColor;
    out vec4 FragColor;

    void main()
    {
        FragColor = vec4(vColor, 1.0);
    }
    )";

    GLuint vs = compile_shader(GL_VERTEX_SHADER, vertexSrc);
    GLuint fs = compile_shader(GL_FRAGMENT_SHADER, fragmentSrc);

    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vs);
    glAttachShader(shaderProgram, fs);
    glLinkProgram(shaderProgram);

    glDeleteShader(vs);
    glDeleteShader(fs);
}
