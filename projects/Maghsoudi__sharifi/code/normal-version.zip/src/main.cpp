#include <iostream>
#include <chrono>

extern bool init_window(int width, int height);
extern bool window_should_close();
extern void swap_buffers();
extern void shutdown_window();

extern void init_pipeline(int N);
extern void render(int N);

extern "C" void nbody_step(float dt, int N);
extern "C" void update_vbo(int N);


int main()
{
    const int N = 104857;

    if (!init_window(800, 600))
        return -1;

    init_pipeline(N);

    // previous frame time
    auto prev_time = std::chrono::high_resolution_clock::now();

    while (!window_should_close())
    {
        // measure delta time
        auto current_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<float> delta = current_time - prev_time;
        float dt = 0.001f;
        prev_time = current_time;

        nbody_step(dt, N);
        update_vbo(N);

        render(N);
        swap_buffers();
    }

    shutdown_window();
    return 0;
}
