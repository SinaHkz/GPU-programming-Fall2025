#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <device_launch_parameters.h>

#include <iostream>
#include <vector>
#include <cmath>

constexpr int   BLOCK_SIZE   = 512;
constexpr float SOFTENING    = 1e-6f;
constexpr float PI           = 3.14159265358979323846f;
constexpr float G_AU         = 4.0f * PI * PI;
constexpr float COEFFICIENT  = G_AU;


// Visual mapping (CUDA writes world-space positions & radii into the VBO)
// Distances are intentionally "beautified" (not physically accurate), so everything stays visible.
constexpr float AU_TO_WORLD            = 1.00f;
constexpr float EARTH_RADIUS_WORLD     = 0.030f;
constexpr float VISUAL_RADIUS_EXP      = 1.00f; // linear radius mapping
constexpr float MIN_MOON_RADIUS_WORLD  = 0.012f;

static float4* d_posMass      = nullptr;
static float4* d_vel          = nullptr;
static float4* d_acc          = nullptr;
static float*  d_radius_world = nullptr;

// Procedural moon orbits ("fake" but stable and visible)
static int*   d_moon_parent = nullptr; // [15]
static float* d_moon_orbit  = nullptr; // [15]
static float* d_moon_angle  = nullptr; // [15]
static float* d_moon_omega  = nullptr; // [15]

static cudaGraphicsResource* cuda_vbo_resource = nullptr;

__global__
void compute_acceleration(
    const float4* __restrict__ posMass,
    float4* __restrict__ acc,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    // Only simulate Sun + planets with N-body. Moons are updated procedurally.
    if (i >= 9) {
        acc[i] = make_float4(0.f, 0.f, 0.f, 0.f);
        return;
    }

    float4 pi = posMass[i];
    float px = pi.x;
    float py = pi.y;
    float pz = pi.z;

    float ax = 0.0f, ay = 0.0f, az = 0.0f;

    __shared__ float4 shPosMass[BLOCK_SIZE];

    for (int tile = 0; tile < N; tile += BLOCK_SIZE)
    {
        int j = tile + threadIdx.x;
        shPosMass[threadIdx.x] = (j < N) ? posMass[j] : make_float4(0.f, 0.f, 0.f, 0.f);

        __syncthreads();

        int tileCount = min(BLOCK_SIZE, N - tile);

        for (int k = 0; k < tileCount; k++)
        {
            int gj = tile + k;
            if (gj == i) continue;

            float4 bj = shPosMass[k];

            float dx = bj.x - px;
            float dy = bj.y - py;
            float dz = bj.z - pz;

            float distSqr = dx*dx + dy*dy + dz*dz + SOFTENING;
            float invDist  = rsqrtf(distSqr);
            float invDist3 = invDist * invDist * invDist;

            float s = bj.w * invDist3;

            ax += dx * s;
            ay += dy * s;
            az += dz * s;
        }

        __syncthreads();
    }

    acc[i] = make_float4(ax * COEFFICIENT, ay * COEFFICIENT, az * COEFFICIENT, 0.f);
}

__global__
void integrate(
    float4* __restrict__ posMass,
    float4* __restrict__ vel,
    const float4* __restrict__ acc,
    float dt,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    if (i == 0) {
        posMass[0].x = 0.f; posMass[0].y = 0.f; posMass[0].z = 0.f;
        vel[0].x = 0.f; vel[0].y = 0.f; vel[0].z = 0.f;
        return;
    }

    // Moons are controlled procedurally (skip N-body integration)
    if (i >= 9) return;

    float4 v = vel[i];
    float4 a = acc[i];
    float4 p = posMass[i];

    v.x += dt * a.x;
    v.y += dt * a.y;
    v.z += dt * a.z;

    p.x += dt * v.x;
    p.y += dt * v.y;
    p.z += dt * v.z;

    vel[i]     = v;
    posMass[i] = p;
}

__global__
void pack_vbo(
    const float4* __restrict__ posMass,
    const float*  __restrict__ radius_world,
    float4* __restrict__ outVbo,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    float4 p = posMass[i];
    outVbo[i] = make_float4(p.x * AU_TO_WORLD, p.y * AU_TO_WORLD, p.z * AU_TO_WORLD, radius_world[i]);
}



__global__
void update_moons(
    float4* __restrict__ posMass,
    float4* __restrict__ vel,
    int*   __restrict__ moon_parent,
    float* __restrict__ moon_orbit,
    float* __restrict__ moon_angle,
    float* __restrict__ moon_omega,
    float dt)
{
    int m = blockIdx.x * blockDim.x + threadIdx.x;
    if (m >= 15) return;

    const int idx = 9 + m;
    const int p   = moon_parent[m];

    float ang = moon_angle[m] + moon_omega[m] * dt;

    const float twoPi = 2.0f * PI;
    if (ang > twoPi) {
        ang -= twoPi * floorf(ang / twoPi);
    }
    moon_angle[m] = ang;

    const float r = moon_orbit[m];
    const float c = cosf(ang);
    const float s = sinf(ang);

    posMass[idx].x = posMass[p].x + r * c;
    posMass[idx].y = posMass[p].y + r * s;
    posMass[idx].z = posMass[p].z;

    const float v = r * moon_omega[m];
    vel[idx].x = vel[p].x - v * s;
    vel[idx].y = vel[p].y + v * c;
    vel[idx].z = vel[p].z;

    posMass[idx].w = 0.0f;
}

static float radius_to_world(float radius_E, bool isMoon)
{
    float r = EARTH_RADIUS_WORLD * powf(radius_E, VISUAL_RADIUS_EXP);
    if (isMoon) r = fmaxf(r, MIN_MOON_RADIUS_WORLD);
    return r;
}

static void make_solar_system(
    std::vector<float4>& h_posMass,
    std::vector<float4>& h_vel,
    std::vector<float>&  h_radius_world,
    std::vector<int>&    h_moon_parent,
    std::vector<float>&  h_moon_orbit,
    std::vector<float>&  h_moon_angle,
    std::vector<float>&  h_moon_omega)
{
    const int N = (int)h_posMass.size();
    if (N < 24) {
        std::cerr << "Solar system setup expects N=24
";
        std::exit(1);
    }

    // Sun
    h_posMass[0] = make_float4(0.f, 0.f, 0.f, 1.0f);
    h_vel[0]     = make_float4(0.f, 0.f, 0.f, 0.f);
    h_radius_world[0] = radius_to_world(2.3f, false);

    struct PlanetDef { float a, m, rE, ang; };
    const PlanetDef planets[8] = {
        { 0.35f, 2.0e-6f, 0.85f, 0.00f },
        { 0.55f, 2.2e-6f, 1.05f, 0.65f },
        { 0.75f, 2.4e-6f, 1.10f, 1.30f },
        { 0.95f, 2.0e-6f, 0.95f, 2.10f },
        { 1.20f, 3.0e-6f, 1.55f, 2.85f },
        { 1.45f, 2.8e-6f, 1.40f, 3.55f },
        { 1.70f, 2.6e-6f, 1.25f, 4.20f },
        { 1.95f, 2.6e-6f, 1.25f, 4.90f },
    };

    for (int p = 0; p < 8; ++p)
    {
        const int idx = 1 + p;
        const float a = planets[p].a;
        const float ang = planets[p].ang;

        const float x = a * cosf(ang);
        const float y = a * sinf(ang);

        const float v  = sqrtf(G_AU * h_posMass[0].w / a);
        const float vx = -sinf(ang) * v;
        const float vy =  cosf(ang) * v;

        h_posMass[idx] = make_float4(x, y, 0.f, planets[p].m);
        h_vel[idx]     = make_float4(vx, vy, 0.f, 0.f);
        h_radius_world[idx] = radius_to_world(planets[p].rE, false);
    }

    struct MoonDef { int parent; float rAU; float rE; float ang; float mul; };
    const MoonDef moons[15] = {
        { 1, 0.060f, 0.55f, 0.30f, 1.00f },
        { 2, 0.070f, 0.60f, 1.10f, 1.00f },
        { 3, 0.090f, 0.70f, 2.00f, 1.00f },
        { 4, 0.060f, 0.55f, 0.50f, 1.10f },
        { 4, 0.085f, 0.55f, 2.60f, 0.95f },
        { 5, 0.070f, 0.65f, 0.20f, 1.20f },
        { 5, 0.085f, 0.60f, 1.30f, 1.10f },
        { 5, 0.100f, 0.70f, 2.10f, 1.00f },
        { 5, 0.115f, 0.60f, 2.90f, 0.95f },
        { 6, 0.075f, 0.70f, 0.90f, 1.10f },
        { 6, 0.095f, 0.60f, 2.20f, 1.00f },
        { 6, 0.115f, 0.55f, 1.60f, 0.95f },
        { 7, 0.080f, 0.60f, 0.60f, 1.05f },
        { 7, 0.105f, 0.58f, 2.40f, 0.95f },
        { 8, 0.095f, 0.65f, 1.70f, 1.00f },
    };

    h_moon_parent.resize(15);
    h_moon_orbit.resize(15);
    h_moon_angle.resize(15);
    h_moon_omega.resize(15);

    const float baseOmega = 7.5f;

    for (int m = 0; m < 15; ++m)
    {
        const int idx = 9 + m;
        const int p = moons[m].parent;
        const float r = moons[m].rAU;
        const float ang = moons[m].ang;
        const float omega = (baseOmega / sqrtf(fmaxf(r, 1e-6f))) * moons[m].mul;

        const float c = cosf(ang);
        const float s = sinf(ang);

        h_posMass[idx] = make_float4(h_posMass[p].x + r * c,
                                     h_posMass[p].y + r * s,
                                     0.f,
                                     0.0f);

        const float vrel = r * omega;
        h_vel[idx] = make_float4(h_vel[p].x - vrel * s,
                                 h_vel[p].y + vrel * c,
                                 0.f,
                                 0.f);

        h_radius_world[idx] = radius_to_world(moons[m].rE, true);

        h_moon_parent[m] = p;
        h_moon_orbit[m]  = r;
        h_moon_angle[m]  = ang;
        h_moon_omega[m]  = omega;
    }
}

// ------------------------------------------------------------
// API
// ------------------------------------------------------------

extern "C"
void init_nbody(int N, cudaGraphicsResource* resource)
{
    cuda_vbo_resource = resource;

    const size_t bytes4 = (size_t)N * sizeof(float4);
    const size_t bytes1 = (size_t)N * sizeof(float);

    cudaMalloc(&d_posMass, bytes4);
    cudaMalloc(&d_vel,     bytes4);
    cudaMalloc(&d_acc,     bytes4);
    cudaMalloc(&d_radius_world, bytes1);

    cudaMalloc(&d_moon_parent, 15 * sizeof(int));
    cudaMalloc(&d_moon_orbit,  15 * sizeof(float));
    cudaMalloc(&d_moon_angle,  15 * sizeof(float));
    cudaMalloc(&d_moon_omega,  15 * sizeof(float));

    std::vector<float4> h_posMass(N);
    std::vector<float4> h_vel(N);
    std::vector<float>  h_radius_world(N);

    std::vector<int>   h_moon_parent;
    std::vector<float> h_moon_orbit;
    std::vector<float> h_moon_angle;
    std::vector<float> h_moon_omega;

    make_solar_system(h_posMass, h_vel, h_radius_world,
                      h_moon_parent, h_moon_orbit, h_moon_angle, h_moon_omega);

    cudaMemcpy(d_posMass, h_posMass.data(), bytes4, cudaMemcpyHostToDevice);
    cudaMemcpy(d_vel,     h_vel.data(),     bytes4, cudaMemcpyHostToDevice);
    cudaMemcpy(d_radius_world, h_radius_world.data(), bytes1, cudaMemcpyHostToDevice);
    cudaMemcpy(d_moon_parent, h_moon_parent.data(), 15 * sizeof(int),   cudaMemcpyHostToDevice);
    cudaMemcpy(d_moon_orbit,  h_moon_orbit.data(),  15 * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_moon_angle,  h_moon_angle.data(),  15 * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_moon_omega,  h_moon_omega.data(),  15 * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemset(d_acc, 0, bytes4);

    cudaDeviceSynchronize();
}

extern "C"
void nbody_step(float dt, int N)
{
    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    compute_acceleration<<<blocks, threads>>>(d_posMass, d_acc, N);
    integrate<<<blocks, threads>>>(d_posMass, d_vel, d_acc, dt, N);

    update_moons<<<1, 32>>>(d_posMass, d_vel, d_moon_parent, d_moon_orbit, d_moon_angle, d_moon_omega, dt);

    cudaDeviceSynchronize();
}

extern "C"
void update_vbo(int N)
{
    void*  dptr_void = nullptr;
    size_t size = 0;

    cudaGraphicsMapResources(1, &cuda_vbo_resource);
    cudaGraphicsResourceGetMappedPointer(&dptr_void, &size, cuda_vbo_resource);

    float4* dptr = (float4*)dptr_void;

    int threads = 256;
    int blocks  = (N + threads - 1) / threads;

    pack_vbo<<<blocks, threads>>>(d_posMass, d_radius_world, dptr, N);

    cudaDeviceSynchronize();

    cudaGraphicsUnmapResources(1, &cuda_vbo_resource);
}

extern "C"
float get_max_radius_world(int N)
{
    static std::vector<float4> h_posMass;
    static std::vector<float>  h_radius;
    h_posMass.resize((size_t)N);
    h_radius.resize((size_t)N);

    const size_t bytes4 = (size_t)N * sizeof(float4);
    const size_t bytes1 = (size_t)N * sizeof(float);

    cudaError_t e1 = cudaMemcpy(h_posMass.data(), d_posMass, bytes4, cudaMemcpyDeviceToHost);
    cudaError_t e2 = cudaMemcpy(h_radius.data(),  d_radius_world, bytes1, cudaMemcpyDeviceToHost);
    if (e1 != cudaSuccess || e2 != cudaSuccess) {
        std::cerr << "get_max_radius_world: cudaMemcpy failed\n";
        return 1.0f;
    }

    float maxR = 0.0f;
    for (int i = 0; i < N; ++i)
    {
        const float x = h_posMass[i].x;
        const float y = h_posMass[i].y;
        const float z = h_posMass[i].z;
        const float distAU = sqrtf(x*x + y*y + z*z);
        const float rWorld = distAU * AU_TO_WORLD + h_radius[i];
        if (rWorld > maxR) maxR = rWorld;
    }
    return maxR;
}
