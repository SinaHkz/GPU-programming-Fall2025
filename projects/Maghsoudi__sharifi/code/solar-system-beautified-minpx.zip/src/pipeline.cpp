#include <GL/glew.h>
#include <cuda_gl_interop.h>
#include <vector>
#include <cmath>
#include <iostream>

extern "C" void  init_nbody(int N, cudaGraphicsResource* resource);
extern "C" float get_max_radius_world(int N);
extern void get_framebuffer_size(int* width, int* height);

extern GLuint shaderProgram;
void init_shader();

GLuint instanceVBO = 0;
GLuint sphereVAO   = 0;
GLuint sphereVBO   = 0;
int sphereVertexCount = 0;

// Must match CUDA VBO layout (float4)
struct RenderBody {
    float x, y, z;
    float radius; // base radius in world units
};

static constexpr float MIN_SUN_PX    = 18.0f;
static constexpr float MIN_PLANET_PX = 7.0f;
static constexpr float MIN_MOON_PX   = 3.0f;

static void create_sphere_mesh(int stacks = 20, int slices = 20)
{
    std::vector<float> vertices;
    vertices.reserve(stacks * slices * 6 * 3);

    for (int i = 0; i < stacks; ++i)
    {
        float phi1 = (float)i / stacks * 3.1415926f;
        float phi2 = (float)(i + 1) / stacks * 3.1415926f;

        for (int j = 0; j < slices; ++j)
        {
            float theta1 = (float)j / slices * 2.0f * 3.1415926f;
            float theta2 = (float)(j + 1) / slices * 2.0f * 3.1415926f;

            auto push = [&](float phi, float theta)
            {
                float x = sinf(phi) * cosf(theta);
                float y = cosf(phi);
                float z = sinf(phi) * sinf(theta);
                vertices.push_back(x);
                vertices.push_back(y);
                vertices.push_back(z);
            };

            // 2 triangles per quad
            push(phi1, theta1);
            push(phi2, theta1);
            push(phi2, theta2);

            push(phi1, theta1);
            push(phi2, theta2);
            push(phi1, theta2);
        }
    }

    sphereVertexCount = (int)(vertices.size() / 3);

    glGenVertexArrays(1, &sphereVAO);
    glBindVertexArray(sphereVAO);

    glGenBuffers(1, &sphereVBO);
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER,
                 vertices.size() * sizeof(float),
                 vertices.data(),
                 GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    glBindVertexArray(0);
}

void init_pipeline(int N)
{
    init_shader();
    create_sphere_mesh();

    // Instance buffer: N bodies, each is (x,y,z,radius)
    glGenBuffers(1, &instanceVBO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
    glBufferData(GL_ARRAY_BUFFER, (size_t)N * sizeof(RenderBody), nullptr, GL_DYNAMIC_DRAW);

    // Register this VBO with CUDA (LOCAL resource handle)
    cudaGraphicsResource* resource = nullptr;
    cudaError_t err = cudaGraphicsGLRegisterBuffer(
        &resource,
        instanceVBO,
        cudaGraphicsMapFlagsWriteDiscard);

    if (err != cudaSuccess) {
        std::cerr << "cudaGraphicsGLRegisterBuffer failed: "
                  << cudaGetErrorString(err) << "\n";
        return;
    }

    // Bind sphere mesh VAO and attach instance attributes
    glBindVertexArray(sphereVAO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);

    // location 1: vec3 position (x,y,z) from instance buffer
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(RenderBody), (void*)0);
    glVertexAttribDivisor(1, 1);

    // location 2: float radius from instance buffer (offset 3 floats)
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(RenderBody), (void*)(3 * sizeof(float)));
    glVertexAttribDivisor(2, 1);

    glBindVertexArray(0);

    // Pass CUDA resource to simulation
    init_nbody(N, resource);
}

void render(int N)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glUseProgram(shaderProgram);

    // Dynamic "auto-zoom": fit the entire system in view every frame.
    // get_max_radius_world() includes base radii, and we also pad for the shader's
    // minimum-pixel radii so spheres never clip.
    int fbW = 0, fbH = 0;
    get_framebuffer_size(&fbW, &fbH);
    if (fbW <= 0 || fbH <= 0) {
        fbW = 1; fbH = 1;
    }

    const float aspect = (float)fbW / (float)fbH;
    const float Rraw   = fmaxf(get_max_radius_world(N), 1e-6f);

    // Tight framing (bigger on screen) + safety margin
    const float margin = 1.01f;

    // Numerator used by the old scale (kept so the math stays consistent)
    const float k = (fminf(1.0f, aspect)) / margin;

    // Extra padding so "min pixel radius" spheres never clip.
    const float minPxMax = fmaxf(MIN_SUN_PX, fmaxf(MIN_PLANET_PX, MIN_MOON_PX));
    float factor = minPxMax / (k * (fbH * 0.5f));
    factor = fminf(fmaxf(factor, 0.0f), 0.25f); // safety clamp

    const float Rfit = Rraw / (1.0f - factor);

    const float scale = k / Rfit;
    const float sx = scale / aspect;
    const float sy = scale;
    const float sz = -scale;

    float projection[16] = {
        sx,0,0,0,
        0,sy,0,0,
        0,0,sz,0,
        0,0,0,1
    };

    float view[16] = {
        1.f,0,0,0,
        0,1.f,0,0,
        0,0,1.f,0,
        0,0,0,1
    };

    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, projection);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"),       1, GL_FALSE, view);

    // Provide viewport + min pixel sizes to the vertex shader
    glUniform2f(glGetUniformLocation(shaderProgram, "viewport"), (float)fbW, (float)fbH);
    glUniform1f(glGetUniformLocation(shaderProgram, "minSunPx"),    MIN_SUN_PX);
    glUniform1f(glGetUniformLocation(shaderProgram, "minPlanetPx"), MIN_PLANET_PX);
    glUniform1f(glGetUniformLocation(shaderProgram, "minMoonPx"),   MIN_MOON_PX);

    glBindVertexArray(sphereVAO);
    glDrawArraysInstanced(GL_TRIANGLES, 0, sphereVertexCount, N);

    glBindVertexArray(0);
    glUseProgram(0);
}
