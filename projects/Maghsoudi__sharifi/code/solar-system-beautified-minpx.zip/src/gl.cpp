#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

GLFWwindow* window = nullptr;

static void framebuffer_size_callback(GLFWwindow* /*w*/, int width, int height)
{
    glViewport(0, 0, width, height);
}

bool init_window(int /*width*/, int /*height*/)
{
    if (!glfwInit())
        return false;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    // Fullscreen on primary monitor
    GLFWmonitor* monitor = glfwGetPrimaryMonitor();
    const GLFWvidmode* mode = glfwGetVideoMode(monitor);
    if (!mode)
        return false;

    window = glfwCreateWindow(mode->width, mode->height, "CUDA Solar System", monitor, nullptr);
    if (!window)
        return false;

    glfwMakeContextCurrent(window);

    // Enable vsync to avoid wasting GPU cycles
    glfwSwapInterval(1);

    if (glewInit() != GLEW_OK)
        return false;

    int fbW = 0, fbH = 0;
    glfwGetFramebufferSize(window, &fbW, &fbH);
    glViewport(0, 0, fbW, fbH);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Space background
    glClearColor(0.0f, 0.0f, 0.02f, 1.0f);

    return true;
}

void get_framebuffer_size(int* width, int* height)
{
    if (!window) { *width = 0; *height = 0; return; }
    glfwGetFramebufferSize(window, width, height);
}

bool window_should_close()
{
    return glfwWindowShouldClose(window);
}

void swap_buffers()
{
    glfwSwapBuffers(window);
    glfwPollEvents();
}

void shutdown_window()
{
    glfwTerminate();
}
