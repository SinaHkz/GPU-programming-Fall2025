#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <device_launch_parameters.h>

#include <iostream>
#include <vector>
#include <cmath>

constexpr int   BLOCK_SIZE   = 512;
constexpr float SOFTENING    = 1e-6f;                 // in AU^2
constexpr float PI           = 3.14159265358979323846f;
constexpr float G_AU         = 4.0f * PI * PI;        // AU^3 / (solar_mass * year^2)
constexpr float COEFFICIENT  = G_AU;

// Visual mapping (CUDA writes world-space positions & radii into the VBO)
// Distances are intentionally "beautified" (not physically accurate), so everything stays visible.
constexpr float AU_TO_WORLD            = 1.00f;
constexpr float EARTH_RADIUS_WORLD     = 0.030f;
constexpr float VISUAL_RADIUS_EXP      = 1.00f; // linear radius mapping
constexpr float MIN_MOON_RADIUS_WORLD  = 0.012f;

// ---------------------- CUDA error checking ----------------------

#define CUDA_CHECK(x) do {                                   \
    cudaError_t err__ = (x);                                 \
    if (err__ != cudaSuccess) {                              \
        std::cerr << "CUDA error: "                           \
                  << cudaGetErrorString(err__)               \
                  << " at " << __FILE__ << ":" << __LINE__   \
                  << std::endl;                              \
        std::exit(1);                                        \
    }                                                        \
} while (0)

// ---------------------- Device buffers ----------------------

static float4* d_posMass       = nullptr; // (x_AU, y_AU, z_AU, mass_solar)
static float4* d_vel           = nullptr; // (vx_AU/yr, vy_AU/yr, vz_AU/yr, unused)
static float4* d_acc           = nullptr; // (ax_AU/yr^2, ay_AU/yr^2, az_AU/yr^2, unused)
static float*  d_radius_world  = nullptr; // base visual radius in world units (already scaled)

// Procedural moon orbits ("fake" but stable and visible)
static int*   d_moon_parent = nullptr; // [15] parent body index for each moon
static float* d_moon_orbit  = nullptr; // [15] orbit radius around parent (AU units in simulation space)
static float* d_moon_angle  = nullptr; // [15] current angle (radians)
static float* d_moon_omega  = nullptr; // [15] angular speed (radians/year)

// IMPORTANT: must be a real global (pipeline.cpp uses extern)
cudaGraphicsResource* cuda_vbo_resource = nullptr;

// Interop stream (so we can safely sync before unmap)
static cudaStream_t interopStream = nullptr;

// ------------------------------------------------------------
// KERNELS
// ------------------------------------------------------------

__global__
void compute_acceleration(
    const float4* __restrict__ posMass,
    float4* __restrict__ acc,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    // Only simulate Sun + planets with N-body. Moons are updated procedurally.
    if (i >= 9) {
        acc[i] = make_float4(0.f, 0.f, 0.f, 0.f);
        return;
    }

    float4 pi = posMass[i];
    float px = pi.x;
    float py = pi.y;
    float pz = pi.z;

    float ax = 0.0f, ay = 0.0f, az = 0.0f;

    __shared__ float4 shPosMass[BLOCK_SIZE];

    for (int tile = 0; tile < N; tile += BLOCK_SIZE)
    {
        int j = tile + threadIdx.x;

        shPosMass[threadIdx.x] =
            (j < N) ? posMass[j] : make_float4(0.f, 0.f, 0.f, 0.f);

        __syncthreads();

        int remaining = N - tile;
        int tileCount = (remaining < BLOCK_SIZE) ? remaining : BLOCK_SIZE;

        int k = 0;
        for (; k + 15 < tileCount; k += 16)
        {
            // 0
            int gj0 = tile + k + 0;
            float4 bj0 = shPosMass[k + 0];
            if (gj0 != i) {
                float dx0 = bj0.x - px, dy0 = bj0.y - py, dz0 = bj0.z - pz;
                float distSqr0 = dx0*dx0 + dy0*dy0 + dz0*dz0 + SOFTENING;
                float invDist0 = rsqrtf(distSqr0);
                float s0 = bj0.w * (invDist0 * invDist0 * invDist0);
                ax += dx0*s0; ay += dy0*s0; az += dz0*s0;
            }

            // 1
            int gj1 = tile + k + 1;
            float4 bj1 = shPosMass[k + 1];
            if (gj1 != i) {
                float dx1 = bj1.x - px, dy1 = bj1.y - py, dz1 = bj1.z - pz;
                float distSqr1 = dx1*dx1 + dy1*dy1 + dz1*dz1 + SOFTENING;
                float invDist1 = rsqrtf(distSqr1);
                float s1 = bj1.w * (invDist1 * invDist1 * invDist1);
                ax += dx1*s1; ay += dy1*s1; az += dz1*s1;
            }

            // 2
            int gj2 = tile + k + 2;
            float4 bj2 = shPosMass[k + 2];
            if (gj2 != i) {
                float dx2 = bj2.x - px, dy2 = bj2.y - py, dz2 = bj2.z - pz;
                float distSqr2 = dx2*dx2 + dy2*dy2 + dz2*dz2 + SOFTENING;
                float invDist2 = rsqrtf(distSqr2);
                float s2 = bj2.w * (invDist2 * invDist2 * invDist2);
                ax += dx2*s2; ay += dy2*s2; az += dz2*s2;
            }

            // 3
            int gj3 = tile + k + 3;
            float4 bj3 = shPosMass[k + 3];
            if (gj3 != i) {
                float dx3 = bj3.x - px, dy3 = bj3.y - py, dz3 = bj3.z - pz;
                float distSqr3 = dx3*dx3 + dy3*dy3 + dz3*dz3 + SOFTENING;
                float invDist3 = rsqrtf(distSqr3);
                float s3 = bj3.w * (invDist3 * invDist3 * invDist3);
                ax += dx3*s3; ay += dy3*s3; az += dz3*s3;
            }

            // 4
            int gj4 = tile + k + 4;
            float4 bj4 = shPosMass[k + 4];
            if (gj4 != i) {
                float dx4 = bj4.x - px, dy4 = bj4.y - py, dz4 = bj4.z - pz;
                float distSqr4 = dx4*dx4 + dy4*dy4 + dz4*dz4 + SOFTENING;
                float invDist4 = rsqrtf(distSqr4);
                float s4 = bj4.w * (invDist4 * invDist4 * invDist4);
                ax += dx4*s4; ay += dy4*s4; az += dz4*s4;
            }

            // 5
            int gj5 = tile + k + 5;
            float4 bj5 = shPosMass[k + 5];
            if (gj5 != i) {
                float dx5 = bj5.x - px, dy5 = bj5.y - py, dz5 = bj5.z - pz;
                float distSqr5 = dx5*dx5 + dy5*dy5 + dz5*dz5 + SOFTENING;
                float invDist5 = rsqrtf(distSqr5);
                float s5 = bj5.w * (invDist5 * invDist5 * invDist5);
                ax += dx5*s5; ay += dy5*s5; az += dz5*s5;
            }

            // 6
            int gj6 = tile + k + 6;
            float4 bj6 = shPosMass[k + 6];
            if (gj6 != i) {
                float dx6 = bj6.x - px, dy6 = bj6.y - py, dz6 = bj6.z - pz;
                float distSqr6 = dx6*dx6 + dy6*dy6 + dz6*dz6 + SOFTENING;
                float invDist6 = rsqrtf(distSqr6);
                float s6 = bj6.w * (invDist6 * invDist6 * invDist6);
                ax += dx6*s6; ay += dy6*s6; az += dz6*s6;
            }

            // 7
            int gj7 = tile + k + 7;
            float4 bj7 = shPosMass[k + 7];
            if (gj7 != i) {
                float dx7 = bj7.x - px, dy7 = bj7.y - py, dz7 = bj7.z - pz;
                float distSqr7 = dx7*dx7 + dy7*dy7 + dz7*dz7 + SOFTENING;
                float invDist7 = rsqrtf(distSqr7);
                float s7 = bj7.w * (invDist7 * invDist7 * invDist7);
                ax += dx7*s7; ay += dy7*s7; az += dz7*s7;
            }

            // 8
            int gj8 = tile + k + 8;
            float4 bj8 = shPosMass[k + 8];
            if (gj8 != i) {
                float dx8 = bj8.x - px, dy8 = bj8.y - py, dz8 = bj8.z - pz;
                float distSqr8 = dx8*dx8 + dy8*dy8 + dz8*dz8 + SOFTENING;
                float invDist8 = rsqrtf(distSqr8);
                float s8 = bj8.w * (invDist8 * invDist8 * invDist8);
                ax += dx8*s8; ay += dy8*s8; az += dz8*s8;
            }

            // 9
            int gj9 = tile + k + 9;
            float4 bj9 = shPosMass[k + 9];
            if (gj9 != i) {
                float dx9 = bj9.x - px, dy9 = bj9.y - py, dz9 = bj9.z - pz;
                float distSqr9 = dx9*dx9 + dy9*dy9 + dz9*dz9 + SOFTENING;
                float invDist9 = rsqrtf(distSqr9);
                float s9 = bj9.w * (invDist9 * invDist9 * invDist9);
                ax += dx9*s9; ay += dy9*s9; az += dz9*s9;
            }

            // 10
            int gj10 = tile + k + 10;
            float4 bj10 = shPosMass[k + 10];
            if (gj10 != i) {
                float dx10 = bj10.x - px, dy10 = bj10.y - py, dz10 = bj10.z - pz;
                float distSqr10 = dx10*dx10 + dy10*dy10 + dz10*dz10 + SOFTENING;
                float invDist10 = rsqrtf(distSqr10);
                float s10 = bj10.w * (invDist10 * invDist10 * invDist10);
                ax += dx10*s10; ay += dy10*s10; az += dz10*s10;
            }

            // 11
            int gj11 = tile + k + 11;
            float4 bj11 = shPosMass[k + 11];
            if (gj11 != i) {
                float dx11 = bj11.x - px, dy11 = bj11.y - py, dz11 = bj11.z - pz;
                float distSqr11 = dx11*dx11 + dy11*dy11 + dz11*dz11 + SOFTENING;
                float invDist11 = rsqrtf(distSqr11);
                float s11 = bj11.w * (invDist11 * invDist11 * invDist11);
                ax += dx11*s11; ay += dy11*s11; az += dz11*s11;
            }

            // 12
            int gj12 = tile + k + 12;
            float4 bj12 = shPosMass[k + 12];
            if (gj12 != i) {
                float dx12 = bj12.x - px, dy12 = bj12.y - py, dz12 = bj12.z - pz;
                float distSqr12 = dx12*dx12 + dy12*dy12 + dz12*dz12 + SOFTENING;
                float invDist12 = rsqrtf(distSqr12);
                float s12 = bj12.w * (invDist12 * invDist12 * invDist12);
                ax += dx12*s12; ay += dy12*s12; az += dz12*s12;
            }

            // 13
            int gj13 = tile + k + 13;
            float4 bj13 = shPosMass[k + 13];
            if (gj13 != i) {
                float dx13 = bj13.x - px, dy13 = bj13.y - py, dz13 = bj13.z - pz;
                float distSqr13 = dx13*dx13 + dy13*dy13 + dz13*dz13 + SOFTENING;
                float invDist13 = rsqrtf(distSqr13);
                float s13 = bj13.w * (invDist13 * invDist13 * invDist13);
                ax += dx13*s13; ay += dy13*s13; az += dz13*s13;
            }

            // 14
            int gj14 = tile + k + 14;
            float4 bj14 = shPosMass[k + 14];
            if (gj14 != i) {
                float dx14 = bj14.x - px, dy14 = bj14.y - py, dz14 = bj14.z - pz;
                float distSqr14 = dx14*dx14 + dy14*dy14 + dz14*dz14 + SOFTENING;
                float invDist14 = rsqrtf(distSqr14);
                float s14 = bj14.w * (invDist14 * invDist14 * invDist14);
                ax += dx14*s14; ay += dy14*s14; az += dz14*s14;
            }

            // 15
            int gj15 = tile + k + 15;
            float4 bj15 = shPosMass[k + 15];
            if (gj15 != i) {
                float dx15 = bj15.x - px, dy15 = bj15.y - py, dz15 = bj15.z - pz;
                float distSqr15 = dx15*dx15 + dy15*dy15 + dz15*dz15 + SOFTENING;
                float invDist15 = rsqrtf(distSqr15);
                float s15 = bj15.w * (invDist15 * invDist15 * invDist15);
                ax += dx15*s15; ay += dy15*s15; az += dz15*s15;
            }
        }

        for (; k < tileCount; k++)
        {
            int gj = tile + k;
            if (gj == i) continue;

            float4 bj = shPosMass[k];
            float dx = bj.x - px;
            float dy = bj.y - py;
            float dz = bj.z - pz;

            float distSqr = dx*dx + dy*dy + dz*dz + SOFTENING;
            float invDist  = rsqrtf(distSqr);
            float invDist3 = invDist * invDist * invDist;

            float s = bj.w * invDist3;

            ax += dx * s;
            ay += dy * s;
            az += dz * s;
        }

        __syncthreads();
    }

    acc[i] = make_float4(ax * COEFFICIENT, ay * COEFFICIENT, az * COEFFICIENT, 0.f);
}

__global__
void integrate(
    float4* __restrict__ posMass,
    float4* __restrict__ vel,
    const float4* __restrict__ acc,
    float dt,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    // Keep the Sun pinned at the origin for a stable camera
    if (i == 0) {
        posMass[0].x = 0.f; posMass[0].y = 0.f; posMass[0].z = 0.f;
        vel[0].x = 0.f; vel[0].y = 0.f; vel[0].z = 0.f;
        return;
    }

    // Moons are controlled procedurally (skip N-body integration)
    if (i >= 9) return;

    float4 v = vel[i];
    float4 a = acc[i];
    float4 p = posMass[i];

    // semi-implicit Euler (symplectic): v <- v + a*dt, p <- p + v*dt
    v.x += dt * a.x;
    v.y += dt * a.y;
    v.z += dt * a.z;

    p.x += dt * v.x;
    p.y += dt * v.y;
    p.z += dt * v.z;

    vel[i]     = v;
    posMass[i] = p;
}


__global__
void update_moons(
    float4* __restrict__ posMass,
    float4* __restrict__ vel,
    int*   __restrict__ moon_parent,
    float* __restrict__ moon_orbit,
    float* __restrict__ moon_angle,
    float* __restrict__ moon_omega,
    float dt)
{
    int m = blockIdx.x * blockDim.x + threadIdx.x;
    if (m >= 15) return;

    const int idx = 9 + m;
    const int p   = moon_parent[m];

    float ang = moon_angle[m] + moon_omega[m] * dt;

    // Keep angle bounded to avoid precision loss over long runs
    const float twoPi = 2.0f * PI;
    if (ang > twoPi) {
        ang -= twoPi * floorf(ang / twoPi);
    }

    moon_angle[m] = ang;

    const float r = moon_orbit[m];
    const float c = cosf(ang);
    const float s = sinf(ang);

    // Position: parent center + orbital offset
    posMass[idx].x = posMass[p].x + r * c;
    posMass[idx].y = posMass[p].y + r * s;
    posMass[idx].z = posMass[p].z;

    // Velocity: parent velocity + tangential component
    const float v = r * moon_omega[m];
    vel[idx].x = vel[p].x - v * s;
    vel[idx].y = vel[p].y + v * c;
    vel[idx].z = vel[p].z;

    // Moons are massless in physics (so they never perturb planets)
    posMass[idx].w = 0.0f;
}

__global__
void pack_vbo(
    const float4* __restrict__ posMass,
    const float*  __restrict__ radius_world,
    float4* __restrict__ outVbo,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    float4 p = posMass[i];
    outVbo[i] = make_float4(p.x * AU_TO_WORLD, p.y * AU_TO_WORLD, p.z * AU_TO_WORLD, radius_world[i]);
}

// ------------------------------------------------------------
// Host-side solar system init
// ------------------------------------------------------------


struct BodyDef {
    const char* name;
    int   parent;      // -1 for Sun
    float orbit_AU;    // distance to parent (circular)
    float mass_solar;  // mass in solar masses (physics)
    float radius_E;    // "visual" radius scale (not real)
};

static float radius_to_world(float radius_E, bool isMoon)
{
    // Intentionally NOT physically accurate:
    // - linear mapping keeps bodies readable
    // - moons are clamped so they never disappear
    float r = EARTH_RADIUS_WORLD * powf(radius_E, VISUAL_RADIUS_EXP);
    if (isMoon) r = fmaxf(r, MIN_MOON_RADIUS_WORLD);
    return r;
}

static void make_solar_system(
    std::vector<float4>& h_posMass,
    std::vector<float4>& h_vel,
    std::vector<float>&  h_radius_world,
    std::vector<int>&    h_moon_parent,
    std::vector<float>&  h_moon_orbit,
    std::vector<float>&  h_moon_angle,
    std::vector<float>&  h_moon_omega)
{
    // Total bodies (must match main.cpp)
    // 0 Sun
    // 1..8 planets
    // 9..23 moons (procedural orbits around parent planets)

    const int N = (int)h_posMass.size();
    if (N < 24) {
        std::cerr << "Solar system setup expects N=24
";
        std::exit(1);
    }

    // Sun (pinned in integrate())
    h_posMass[0] = make_float4(0.f, 0.f, 0.f, 1.0f);
    h_vel[0]     = make_float4(0.f, 0.f, 0.f, 0.f);
    h_radius_world[0] = radius_to_world(2.3f, false); // big + readable

    struct PlanetDef { float a, m, rE, angle; };
    // "Beautified" orbits: compact, evenly spaced, always visible
    const PlanetDef planets[8] = {
        //  a(AU-ish)  mass(solar)   radiusScale(E)  angle(rad)
        { 0.35f,      2.0e-6f,      0.85f,          0.00f }, // Mercury
        { 0.55f,      2.2e-6f,      1.05f,          0.65f }, // Venus
        { 0.75f,      2.4e-6f,      1.10f,          1.30f }, // Earth
        { 0.95f,      2.0e-6f,      0.95f,          2.10f }, // Mars
        { 1.20f,      3.0e-6f,      1.55f,          2.85f }, // Jupiter
        { 1.45f,      2.8e-6f,      1.40f,          3.55f }, // Saturn
        { 1.70f,      2.6e-6f,      1.25f,          4.20f }, // Uranus
        { 1.95f,      2.6e-6f,      1.25f,          4.90f }, // Neptune
    };

    for (int p = 0; p < 8; ++p)
    {
        const int idx = 1 + p;
        const float a   = planets[p].a;
        const float ang = planets[p].angle;

        const float x = a * cosf(ang);
        const float y = a * sinf(ang);

        // circular orbit speed around the Sun (still using Kepler-ish formula)
        const float v  = sqrtf(G_AU * h_posMass[0].w / a);
        const float vx = -sinf(ang) * v;
        const float vy =  cosf(ang) * v;

        h_posMass[idx] = make_float4(x, y, 0.f, planets[p].m);
        h_vel[idx]     = make_float4(vx, vy, 0.f, 0.f);
        h_radius_world[idx] = radius_to_world(planets[p].rE, false);
    }

    // Moons: procedural orbits (fake but always stable and visible)
    struct MoonDef { int parentIdx; float orbitAU; float rE; float ang; float omegaMul; };
    const MoonDef moons[15] = {
        // parent, orbit,  radiusScale, ang,  omegaMul
        { 1, 0.060f, 0.55f, 0.30f, 1.00f }, // Mercury moon (fictional)
        { 2, 0.070f, 0.60f, 1.10f, 1.00f }, // Venus moon   (fictional)
        { 3, 0.090f, 0.70f, 2.00f, 1.00f }, // Earth's Moon

        { 4, 0.060f, 0.55f, 0.50f, 1.10f }, // Mars moon
        { 4, 0.085f, 0.55f, 2.60f, 0.95f }, // Mars moon

        { 5, 0.070f, 0.65f, 0.20f, 1.20f }, // Jupiter moon
        { 5, 0.085f, 0.60f, 1.30f, 1.10f }, // Jupiter moon
        { 5, 0.100f, 0.70f, 2.10f, 1.00f }, // Jupiter moon
        { 5, 0.115f, 0.60f, 2.90f, 0.95f }, // Jupiter moon

        { 6, 0.075f, 0.70f, 0.90f, 1.10f }, // Saturn moon
        { 6, 0.095f, 0.60f, 2.20f, 1.00f }, // Saturn moon
        { 6, 0.115f, 0.55f, 1.60f, 0.95f }, // Saturn moon

        { 7, 0.080f, 0.60f, 0.60f, 1.05f }, // Uranus moon
        { 7, 0.105f, 0.58f, 2.40f, 0.95f }, // Uranus moon

        { 8, 0.095f, 0.65f, 1.70f, 1.00f }, // Neptune moon
    };

    h_moon_parent.resize(15);
    h_moon_orbit.resize(15);
    h_moon_angle.resize(15);
    h_moon_omega.resize(15);

    const float baseOmega = 7.5f; // larger => faster moon orbits

    for (int m = 0; m < 15; ++m)
    {
        const int idx = 9 + m;
        const int parent = moons[m].parentIdx;

        const float r   = moons[m].orbitAU;
        const float ang = moons[m].ang;

        // Fake-but-nice angular speed (independent of gravity/Hill sphere)
        const float omega = (baseOmega / sqrtf(fmaxf(r, 1e-6f))) * moons[m].omegaMul;

        const float c = cosf(ang);
        const float s = sinf(ang);

        // Position relative to parent
        h_posMass[idx] = make_float4(h_posMass[parent].x + r * c,
                                     h_posMass[parent].y + r * s,
                                     0.f,
                                     0.0f /* massless */);

        // Velocity relative to parent
        const float vrel = r * omega;
        h_vel[idx] = make_float4(h_vel[parent].x - vrel * s,
                                 h_vel[parent].y + vrel * c,
                                 0.f,
                                 0.f);

        h_radius_world[idx] = radius_to_world(moons[m].rE, true);

        // Store procedural parameters
        h_moon_parent[m] = parent;
        h_moon_orbit[m]  = r;
        h_moon_angle[m]  = ang;
        h_moon_omega[m]  = omega;
    }
}


// ------------------------------------------------------------
// API
// ------------------------------------------------------------

extern "C"
void init_nbody(int N, cudaGraphicsResource* resource)
{
    cuda_vbo_resource = resource;

    const size_t bytes4 = static_cast<size_t>(N) * sizeof(float4);
    const size_t bytes1 = static_cast<size_t>(N) * sizeof(float);

    CUDA_CHECK(cudaMalloc(&d_posMass, bytes4));
    CUDA_CHECK(cudaMalloc(&d_vel,     bytes4));
    CUDA_CHECK(cudaMalloc(&d_acc,     bytes4));
    CUDA_CHECK(cudaMalloc(&d_radius_world, bytes1));

    // Moon procedural parameters
    CUDA_CHECK(cudaMalloc(&d_moon_parent, 15 * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_moon_orbit,  15 * sizeof(float)));
    CUDA_CHECK(cudaMalloc(&d_moon_angle,  15 * sizeof(float)));
    CUDA_CHECK(cudaMalloc(&d_moon_omega,  15 * sizeof(float)));

    // create interop stream once
    if (interopStream == nullptr) {
        CUDA_CHECK(cudaStreamCreate(&interopStream));
    }

    std::vector<float4> h_posMass(N);
    std::vector<float4> h_vel(N);
    std::vector<float>  h_radius_world(N);

    // Moon procedural parameters (15 moons: indices 9..23)
    std::vector<int>   h_moon_parent;
    std::vector<float> h_moon_orbit;
    std::vector<float> h_moon_angle;
    std::vector<float> h_moon_omega;

    make_solar_system(h_posMass, h_vel, h_radius_world,
                      h_moon_parent, h_moon_orbit, h_moon_angle, h_moon_omega);

    CUDA_CHECK(cudaMemcpy(d_posMass, h_posMass.data(), bytes4, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_vel,     h_vel.data(),     bytes4, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_radius_world, h_radius_world.data(), bytes1, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_moon_parent, h_moon_parent.data(), 15 * sizeof(int),   cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_moon_orbit,  h_moon_orbit.data(),  15 * sizeof(float), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_moon_angle,  h_moon_angle.data(),  15 * sizeof(float), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_moon_omega,  h_moon_omega.data(),  15 * sizeof(float), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(d_acc, 0, bytes4));

    CUDA_CHECK(cudaDeviceSynchronize());
}

extern "C"
void nbody_step(float dt, int N)
{
    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    compute_acceleration<<<blocks, threads>>>(d_posMass, d_acc, N);
    CUDA_CHECK(cudaGetLastError());

    integrate<<<blocks, threads>>>(d_posMass, d_vel, d_acc, dt, N);
    CUDA_CHECK(cudaGetLastError());

    // Update moons (indices 9..23) procedurally around their parent planets
    update_moons<<<1, 32>>>(d_posMass, d_vel, d_moon_parent, d_moon_orbit, d_moon_angle, d_moon_omega, dt);
    CUDA_CHECK(cudaGetLastError());

    CUDA_CHECK(cudaDeviceSynchronize());
}

extern "C"
void update_vbo(int N)
{
    void*  dptr_void = nullptr;
    size_t size      = 0;

    CUDA_CHECK(cudaGraphicsMapResources(1, &cuda_vbo_resource, interopStream));
    CUDA_CHECK(cudaGraphicsResourceGetMappedPointer(&dptr_void, &size, cuda_vbo_resource));

    float4* dptr = reinterpret_cast<float4*>(dptr_void);

    int threads = 256;
    int blocks  = (N + threads - 1) / threads;

    pack_vbo<<<blocks, threads, 0, interopStream>>>(d_posMass, d_radius_world, dptr, N);
    CUDA_CHECK(cudaGetLastError());

    // IMPORTANT: wait for VBO writes to finish before unmap
    CUDA_CHECK(cudaStreamSynchronize(interopStream));

    CUDA_CHECK(cudaGraphicsUnmapResources(1, &cuda_vbo_resource, interopStream));
}

extern "C"
float get_max_radius_world(int N)
{
    static std::vector<float4> h_posMass;
    static std::vector<float>  h_radius;

    h_posMass.resize((size_t)N);
    h_radius.resize((size_t)N);

    const size_t bytes4 = (size_t)N * sizeof(float4);
    const size_t bytes1 = (size_t)N * sizeof(float);

    CUDA_CHECK(cudaMemcpy(h_posMass.data(), d_posMass, bytes4, cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(h_radius.data(),  d_radius_world, bytes1, cudaMemcpyDeviceToHost));

    float maxR = 0.0f;
    for (int i = 0; i < N; ++i)
    {
        const float x = h_posMass[i].x;
        const float y = h_posMass[i].y;
        const float z = h_posMass[i].z;
        const float distAU = sqrtf(x*x + y*y + z*z);
        const float rWorld = distAU * AU_TO_WORLD + h_radius[i];
        if (rWorld > maxR) maxR = rWorld;
    }
    return maxR;
}
