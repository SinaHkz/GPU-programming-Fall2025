#include <GL/glew.h>
#include <iostream>

GLuint shaderProgram;

static GLuint compile_shader(GLenum type, const char* src)
{
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);

    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);

    if (!success)
    {
        char info[512];
        glGetShaderInfoLog(shader, 512, nullptr, info);
        std::cout << "Shader compile error:\n" << info << std::endl;
    }

    return shader;
}

void init_shader()
{
    const char* vertexSrc = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec3 instancePos;
    layout (location = 2) in float radius; // base radius in world units

    uniform mat4 projection;
    uniform mat4 view;

    // framebuffer size in pixels
    uniform vec2 viewport;

    // minimum *pixel* radii (guarantee visibility)
    uniform float minSunPx;
    uniform float minPlanetPx;
    uniform float minMoonPx;

    out vec3 vColor;

    vec3 bodyColor(int id)
    {
        // Index mapping (must match CUDA init order)
        // 0 Sun
        // 1..8 planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
        // 9.. moons
        if (id == 0)  return vec3(1.0, 0.92, 0.25);
        if (id == 1)  return vec3(0.65, 0.65, 0.68);
        if (id == 2)  return vec3(0.85, 0.80, 0.55);
        if (id == 3)  return vec3(0.20, 0.45, 0.95);
        if (id == 4)  return vec3(0.85, 0.30, 0.18);
        if (id == 5)  return vec3(0.85, 0.60, 0.30);
        if (id == 6)  return vec3(0.90, 0.80, 0.65);
        if (id == 7)  return vec3(0.55, 0.85, 0.90);
        if (id == 8)  return vec3(0.20, 0.35, 0.85);

        // Moons: neutral gray
        return vec3(0.78, 0.78, 0.82);
    }

    float minRadiusForId(int id)
    {
        if (id == 0) return minSunPx;
        if (id >= 1 && id <= 8) return minPlanetPx;
        return minMoonPx;
    }

    void main()
    {
        // Convert the base world radius to pixels using current projection scale.
        // NOTE: projection is a diagonal matrix in this project.
        float sy = abs(projection[1][1]);
        float worldToPx = sy * (viewport.y * 0.5);
        worldToPx = max(worldToPx, 1e-6);

        float rPxFromWorld = radius * worldToPx;
        float rPx = max(rPxFromWorld, minRadiusForId(gl_InstanceID));

        // Effective world radius that yields the desired pixel radius.
        float rWorld = rPx / worldToPx;

        vec3 pos = instancePos + aPos * rWorld;
        gl_Position = projection * view * vec4(pos, 1.0);

        // Simple fake lighting (unit sphere => normal = aPos)
        vec3 N = normalize(aPos);
        vec3 L = normalize(vec3(0.4, 0.7, 0.2));
        float diff = max(dot(N, L), 0.0);
        float ambient = 0.28;

        vec3 base = bodyColor(gl_InstanceID);
        vColor = base * (ambient + (1.0 - ambient) * diff);

        // Make the Sun glow a bit
        if (gl_InstanceID == 0) {
            vColor = base * 1.15;
        }
    }
    )";

    const char* fragmentSrc = R"(
    #version 330 core
    in vec3 vColor;
    out vec4 FragColor;

    void main()
    {
        FragColor = vec4(vColor, 1.0);
    }
    )";

    GLuint vs = compile_shader(GL_VERTEX_SHADER, vertexSrc);
    GLuint fs = compile_shader(GL_FRAGMENT_SHADER, fragmentSrc);

    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vs);
    glAttachShader(shaderProgram, fs);
    glLinkProgram(shaderProgram);

    glDeleteShader(vs);
    glDeleteShader(fs);
}
