#include <iostream>
#include <chrono>

extern bool init_window(int width, int height);
extern bool window_should_close();
extern void swap_buffers();
extern void shutdown_window();

extern void init_pipeline(int N);
extern void render(int N);

extern "C" void nbody_step(float dt, int N);
extern "C" void update_vbo(int N);

int main()
{
    // Sun + 8 planets + 15 moons = 24 bodies
    const int N = 24;

    if (!init_window(1100, 800))
        return -1;

    init_pipeline(N);

    while (!window_should_close())
    {
        // Units: AU (distance), solar masses (mass), years (time)
        // dt controls the simulation speed.
        const float dt = 0.00020f; // ~0.073 years per 365 frames

        nbody_step(dt, N);
        update_vbo(N);

        render(N);
        swap_buffers();
    }

    shutdown_window();
    return 0;
}
