#include <cuda_runtime.h>
#include <cuda_gl_interop.h>
#include <device_launch_parameters.h>

#include <iostream>
#include <cmath>

constexpr int   BLOCK_SIZE   = 128;
constexpr float SOFTENING    = 1e-6f;                 // AU^2
constexpr float PI           = 3.14159265358979323846f;
constexpr float G_AU         = 4.0f * PI * PI;        // AU^3 / (solar_mass * year^2)
constexpr float COEFFICIENT  = G_AU;

// Visual mapping (CUDA writes world-space positions & radii into the VBO)
// Distances are intentionally "beautified" (not physically accurate), so everything stays visible.
constexpr float AU_TO_WORLD            = 1.00f;
constexpr float EARTH_RADIUS_WORLD     = 0.030f;
constexpr float VISUAL_RADIUS_EXP      = 1.00f;
constexpr float MIN_MOON_RADIUS_WORLD  = 0.012f;

struct RenderBody {
    float x, y, z;
    float radius; // world units
};

// Unified memory (baseline version)
float* pos_x; float* pos_y; float* pos_z;
float* vel_x; float* vel_y; float* vel_z;
float* acc_x; float* acc_y; float* acc_z;
float* mass;         // solar masses (physics)
float* radius_world; // world units (render)

// Procedural moon orbit parameters (managed memory)
int*   moon_parent;
float* moon_orbit;
float* moon_angle;
float* moon_omega;

cudaGraphicsResource* cuda_vbo_resource;

__global__
void compute_acceleration(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* mass,
    float* acc_x,
    float* acc_y,
    float* acc_z,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    // Only simulate Sun + planets with N-body. Moons are updated procedurally.
    if (i >= 9) {
        acc_x[i] = 0.0f; acc_y[i] = 0.0f; acc_z[i] = 0.0f;
        return;
    }

    float px = pos_x[i];
    float py = pos_y[i];
    float pz = pos_z[i];

    float ax = 0.0f;
    float ay = 0.0f;
    float az = 0.0f;

    for (int j = 0; j < N; j++)
    {
        if (j == i) continue;

        float dx = pos_x[j] - px;
        float dy = pos_y[j] - py;
        float dz = pos_z[j] - pz;

        float distSqr  = dx * dx + dy * dy + dz * dz + SOFTENING;
        float invDist  = rsqrtf(distSqr);
        float invDist3 = invDist * invDist * invDist;

        float s = mass[j] * invDist3;

        ax += dx * s;
        ay += dy * s;
        az += dz * s;
    }

    acc_x[i] = ax * COEFFICIENT;
    acc_y[i] = ay * COEFFICIENT;
    acc_z[i] = az * COEFFICIENT;
}

__global__
void integrate(
    float* pos_x,
    float* pos_y,
    float* pos_z,
    float* vel_x,
    float* vel_y,
    float* vel_z,
    const float* acc_x,
    const float* acc_y,
    const float* acc_z,
    float dt,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    // pin the Sun (index 0)
    if (i == 0) {
        pos_x[0] = pos_y[0] = pos_z[0] = 0.f;
        vel_x[0] = vel_y[0] = vel_z[0] = 0.f;
        return;
    }

    // Moons are controlled procedurally (skip N-body integration)
    if (i >= 9) return;

    vel_x[i] += dt * acc_x[i];
    vel_y[i] += dt * acc_y[i];
    vel_z[i] += dt * acc_z[i];

    pos_x[i] += dt * vel_x[i];
    pos_y[i] += dt * vel_y[i];
    pos_z[i] += dt * vel_z[i];
}

__global__
void soa_to_aos(
    const float* pos_x,
    const float* pos_y,
    const float* pos_z,
    const float* radius_world,
    RenderBody* out,
    int N)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= N) return;

    out[i] = { pos_x[i] * AU_TO_WORLD, pos_y[i] * AU_TO_WORLD, pos_z[i] * AU_TO_WORLD, radius_world[i] };
}

static float radius_to_world(float radius_E, bool isMoon)
{
    float r = EARTH_RADIUS_WORLD * powf(radius_E, VISUAL_RADIUS_EXP);
    if (isMoon) r = fmaxf(r, MIN_MOON_RADIUS_WORLD);
    return r;
}



__global__
void update_moons(
    float* pos_x, float* pos_y, float* pos_z,
    float* vel_x, float* vel_y, float* vel_z,
    float* mass,
    int* moon_parent,
    float* moon_orbit,
    float* moon_angle,
    float* moon_omega,
    float dt)
{
    int m = blockIdx.x * blockDim.x + threadIdx.x;
    if (m >= 15) return;

    const int idx = 9 + m;
    const int p   = moon_parent[m];

    float ang = moon_angle[m] + moon_omega[m] * dt;
    const float twoPi = 2.0f * PI;
    if (ang > twoPi) {
        ang -= twoPi * floorf(ang / twoPi);
    }
    moon_angle[m] = ang;

    const float r = moon_orbit[m];
    const float c = cosf(ang);
    const float s = sinf(ang);

    pos_x[idx] = pos_x[p] + r * c;
    pos_y[idx] = pos_y[p] + r * s;
    pos_z[idx] = pos_z[p];

    const float v = r * moon_omega[m];
    vel_x[idx] = vel_x[p] - v * s;
    vel_y[idx] = vel_y[p] + v * c;
    vel_z[idx] = vel_z[p];

    mass[idx] = 0.0f; // keep moons massless
}

static void init_solar_system(int N)
{
    if (N < 24) {
        std::cerr << "Solar system setup expects N=24\n";
        std::exit(1);
    }

    // Sun
    pos_x[0] = pos_y[0] = pos_z[0] = 0.f;
    vel_x[0] = vel_y[0] = vel_z[0] = 0.f;
    mass[0] = 1.0f;
    radius_world[0] = radius_to_world(2.3f, false);

    struct PlanetDef { float a, m, rE, ang; };
    const PlanetDef planets[8] = {
        { 0.35f, 2.0e-6f, 0.85f, 0.00f },
        { 0.55f, 2.2e-6f, 1.05f, 0.65f },
        { 0.75f, 2.4e-6f, 1.10f, 1.30f },
        { 0.95f, 2.0e-6f, 0.95f, 2.10f },
        { 1.20f, 3.0e-6f, 1.55f, 2.85f },
        { 1.45f, 2.8e-6f, 1.40f, 3.55f },
        { 1.70f, 2.6e-6f, 1.25f, 4.20f },
        { 1.95f, 2.6e-6f, 1.25f, 4.90f },
    };

    for (int p = 0; p < 8; ++p)
    {
        const int idx = 1 + p;
        const float a   = planets[p].a;
        const float ang = planets[p].ang;

        pos_x[idx] = a * cosf(ang);
        pos_y[idx] = a * sinf(ang);
        pos_z[idx] = 0.f;

        const float v = sqrtf(G_AU * mass[0] / a);
        vel_x[idx] = -sinf(ang) * v;
        vel_y[idx] =  cosf(ang) * v;
        vel_z[idx] = 0.f;

        mass[idx] = planets[p].m;
        radius_world[idx] = radius_to_world(planets[p].rE, false);
    }

    struct MoonDef { int parent; float rAU; float rE; float ang; float mul; };
    const MoonDef moons[15] = {
        { 1, 0.060f, 0.55f, 0.30f, 1.00f },
        { 2, 0.070f, 0.60f, 1.10f, 1.00f },
        { 3, 0.090f, 0.70f, 2.00f, 1.00f },
        { 4, 0.060f, 0.55f, 0.50f, 1.10f },
        { 4, 0.085f, 0.55f, 2.60f, 0.95f },
        { 5, 0.070f, 0.65f, 0.20f, 1.20f },
        { 5, 0.085f, 0.60f, 1.30f, 1.10f },
        { 5, 0.100f, 0.70f, 2.10f, 1.00f },
        { 5, 0.115f, 0.60f, 2.90f, 0.95f },
        { 6, 0.075f, 0.70f, 0.90f, 1.10f },
        { 6, 0.095f, 0.60f, 2.20f, 1.00f },
        { 6, 0.115f, 0.55f, 1.60f, 0.95f },
        { 7, 0.080f, 0.60f, 0.60f, 1.05f },
        { 7, 0.105f, 0.58f, 2.40f, 0.95f },
        { 8, 0.095f, 0.65f, 1.70f, 1.00f },
    };

    const float baseOmega = 7.5f;

    for (int m = 0; m < 15; ++m)
    {
        const int idx = 9 + m;
        const int p   = moons[m].parent;
        const float r  = moons[m].rAU;
        const float ang = moons[m].ang;
        const float omega = (baseOmega / sqrtf(fmaxf(r, 1e-6f))) * moons[m].mul;

        moon_parent[m] = p;
        moon_orbit[m]  = r;
        moon_angle[m]  = ang;
        moon_omega[m]  = omega;

        const float c = cosf(ang);
        const float s = sinf(ang);

        pos_x[idx] = pos_x[p] + r * c;
        pos_y[idx] = pos_y[p] + r * s;
        pos_z[idx] = 0.f;

        const float vrel = r * omega;
        vel_x[idx] = vel_x[p] - vrel * s;
        vel_y[idx] = vel_y[p] + vrel * c;
        vel_z[idx] = 0.f;

        mass[idx] = 0.0f;
        radius_world[idx] = radius_to_world(moons[m].rE, true);
    }
}

// ------------------------------------------------------------
// API
// ------------------------------------------------------------

extern "C"
void init_nbody(int N, cudaGraphicsResource* resource)
{
    cuda_vbo_resource = resource;

    const size_t bytes = (size_t)N * sizeof(float);

    cudaMallocManaged(&pos_x, bytes);
    cudaMallocManaged(&pos_y, bytes);
    cudaMallocManaged(&pos_z, bytes);

    cudaMallocManaged(&vel_x, bytes);
    cudaMallocManaged(&vel_y, bytes);
    cudaMallocManaged(&vel_z, bytes);

    cudaMallocManaged(&acc_x, bytes);
    cudaMallocManaged(&acc_y, bytes);
    cudaMallocManaged(&acc_z, bytes);

    cudaMallocManaged(&mass, bytes);
    cudaMallocManaged(&radius_world, bytes);

    cudaMallocManaged(&moon_parent, 15 * sizeof(int));
    cudaMallocManaged(&moon_orbit,  15 * sizeof(float));
    cudaMallocManaged(&moon_angle,  15 * sizeof(float));
    cudaMallocManaged(&moon_omega,  15 * sizeof(float));

    init_solar_system(N);

    cudaDeviceSynchronize();
}

extern "C"
void nbody_step(float dt, int N)
{
    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    compute_acceleration<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        mass,
        acc_x, acc_y, acc_z,
        N);

    integrate<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        vel_x, vel_y, vel_z,
        acc_x, acc_y, acc_z,
        dt,
        N);

    update_moons<<<1, 32>>>(pos_x, pos_y, pos_z, vel_x, vel_y, vel_z, mass, moon_parent, moon_orbit, moon_angle, moon_omega, dt);

    cudaDeviceSynchronize();
}

extern "C"
void update_vbo(int N)
{
    RenderBody* dptr;
    size_t size;

    cudaGraphicsMapResources(1, &cuda_vbo_resource);
    cudaGraphicsResourceGetMappedPointer((void**)&dptr, &size, cuda_vbo_resource);

    int threads = BLOCK_SIZE;
    int blocks  = (N + threads - 1) / threads;

    soa_to_aos<<<blocks, threads>>>(
        pos_x, pos_y, pos_z,
        radius_world,
        dptr,
        N);

    cudaGraphicsUnmapResources(1, &cuda_vbo_resource);
}

extern "C"
float get_max_radius_world(int N)
{
    float maxR = 0.0f;
    for (int i = 0; i < N; ++i)
    {
        const float x = pos_x[i];
        const float y = pos_y[i];
        const float z = pos_z[i];
        const float distAU = sqrtf(x*x + y*y + z*z);
        const float rWorld = distAU * AU_TO_WORLD + radius_world[i];
        if (rWorld > maxR) maxR = rWorld;
    }
    return maxR;
}
